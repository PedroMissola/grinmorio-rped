# `index.js`

Este é o arquivo de entrada (`entrypoint`) da aplicação. Ele é responsável por inicializar o servidor Express, configurar todos os middlewares globais, registrar as rotas e iniciar a escuta por requisições HTTP.

## Visão Geral

O fluxo de execução do arquivo é o seguinte:
1.  **Carregamento de Módulos:** Importa o `express`, as dependências de configuração, middlewares, rotas e utilitários. `dotenv.config()` é chamado no início para carregar as variáveis de ambiente do arquivo `.env`.
2.  **Inicialização do Express:** Cria uma instância do aplicativo Express (`const app = express()`).
3.  **Configuração de Middlewares:** Aplica uma série de middlewares globais que serão executados em **todas** as requisições, na ordem em que são declarados.
4.  **Registro de Rotas:** Define os prefixos de URL para cada conjunto de rotas importado.
5.  **Handlers de Erro:** Registra os middlewares para lidar com rotas não encontradas (404) e com outros erros da aplicação.
6.  **Inicialização do Servidor:** A função `startServer` é chamada para conectar aos bancos de dados e, se bem-sucedido, iniciar o servidor web.

## Cadeia de Middlewares Globais

A ordem dos middlewares é crucial para o funcionamento correto e seguro da API.

1.  `helmet`: Aplica vários headers HTTP de segurança como uma primeira camada de defesa (ex: remove o header `X-Powered-By`).
2.  `globalLimiter`: Um `rate-limit` genérico que se aplica a todas as rotas, oferecendo proteção básica contra ataques de força bruta ou DoS.
3.  `express.json()`: Faz o "parse" do corpo de requisições que chegam com `Content-Type: application/json`, tornando os dados acessíveis em `req.body`.
4.  `sanitizeBody`: O middleware customizado que remove operadores de NoSQL Injection (`$`) do `req.body`.
5.  `authenticate`: O middleware de autenticação HMAC. Todas as rotas sob o prefixo `/api` passam por esta verificação.

## Rotas

-   `/health`: Um endpoint público (sem autenticação) que retorna o status da aplicação, seu tempo de atividade (`uptime`) e métricas da fila de auditoria. É essencial para sistemas de monitoramento e health checks automáticos.
-   `/api/...`: As rotas de negócio da aplicação (`roll`, `guilds`, `analytics`, `stats`) são registradas com o prefixo `/api`, garantindo que todas passem pelo middleware `authenticate`.

## Tratamento de Erros

1.  **Handler 404:** Após o registro de todas as rotas válidas, um middleware é usado para capturar qualquer requisição que não tenha correspondido a nenhuma rota anterior. Ele cria um `new AppError` com status 404 e o passa para o handler de erros global.
2.  `errorHandler`: O último middleware na cadeia. Ele recebe qualquer erro passado por `next(error)` e é responsável por logar o erro e enviar uma resposta JSON formatada e segura para o cliente.

## Função `startServer()`

-   **Método:** `async`
-   **Descrição:** Orquestra o processo de inicialização da aplicação.
-   **Lógica:**
    1.  Tenta se conectar ao MongoDB (`connectMongo()`).
    2.  Tenta se conectar ao Redis (`connectRedis()`).
    3.  Se ambas as conexões forem bem-sucedidas, inicia o servidor Express com `app.listen()`.
    4.  Se qualquer uma das conexões falhar, um erro crítico é logado no console e o processo da aplicação é encerrado (`process.exit(1)`), prevenindo que a API rode em um estado inconsistente (sem acesso a um banco de dados essencial).
