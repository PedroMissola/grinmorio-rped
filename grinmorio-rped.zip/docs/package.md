# `package.json`

Este arquivo é o manifesto do projeto Node.js. Ele define os metadados do projeto, as dependências necessárias para executá-lo e os scripts que podem ser usados para interagir com ele.

## Metadados do Projeto

-   `name`: `grinmorio-rped` - O nome do projeto.
-   `version`: `1.0.0` - A versão atual do projeto.
-   `description`: Uma breve descrição (atualmente vazia).
-   `main`: `index.js` - O arquivo de entrada principal da aplicação.
-   `author`: O autor do projeto (atualmente vazio).
-   `license`: `ISC` - A licença sob a qual o projeto é distribuído.

## Scripts

O `package.json` define scripts que podem ser executados com o comando `npm run <script_name>`.

-   `"start": "node index.js"`:
    -   **Comando:** `npm start`
    -   **Ação:** Inicia a aplicação executando o arquivo `index.js` com o Node.js. Este é o comando padrão para rodar o servidor em produção.

-   `"test": "echo "Error: no test specified" && exit 1"`:
    -   **Comando:** `npm test`
    -   **Ação:** O comando de teste padrão. Atualmente, ele apenas exibe uma mensagem de erro e termina com um código de falha, indicando que nenhum framework de teste foi configurado.

## Dependências (`dependencies`)

Esta seção lista todos os pacotes de terceiros que a aplicação precisa para funcionar em produção. Eles são instalados com o comando `npm install`.

-   `dotenv`: Usado para carregar variáveis de ambiente de um arquivo `.env` para `process.env`. Essencial para gerenciar configurações e segredos fora do código-fonte.
-   `express`: O framework web utilizado para construir a API, gerenciar rotas, middlewares, etc.
-   `express-rate-limit`: Um middleware para Express que adiciona limitação de taxa (rate limiting) a endpoints, protegendo contra abuso e ataques de força bruta.
-   `helmet`: Um middleware de segurança para Express que aplica vários headers HTTP para proteger a aplicação de vulnerabilidades web conhecidas.
-   `ioredis`: Um cliente Redis de alta performance para Node.js, usado para interagir com o banco de dados em memória Redis.
-   `mongoose`: Um ODM (Object Data Modeling) para MongoDB, que facilita a interação com o banco de dados, fornecendo schemas, validação e modelagem de dados.
-   `zod`: Uma biblioteca para declaração e validação de schemas de dados, usada para garantir que os dados que chegam à API (ex: `req.body`) estejam no formato correto.
