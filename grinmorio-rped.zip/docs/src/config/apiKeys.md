# `src/config/apiKeys.js`

Este arquivo é responsável por gerenciar os clientes autorizados a consumir a API, funcionando como um registro central de chaves de API.

## Visão Geral

O principal objetivo deste módulo é validar se uma chave de API (`apiKey`) fornecida em uma requisição pertence a um cliente conhecido e recuperar os detalhes desse cliente, como seu nome e o segredo associado.

## Estrutura de Dados

A lista de clientes é armazenada no objeto `API_CLIENTS`. A chave de cada entrada é a própria `apiKey`, e o valor é um objeto contendo:
- `name`: O nome do cliente (ex: 'grinmorio-bot').
- `secret`: O segredo usado para validar a autenticidade do cliente.

As chaves e segredos são carregados a partir de variáveis de ambiente (`process.env`), o que é uma boa prática de segurança para não hardcodar credenciais no código.

```javascript
const API_CLIENTS = {
    [process.env.BOT_API_KEY]: {
        name: 'grinmorio-bot',
        secret: process.env.BOT_API_SECRET
    }
};
```

O design suporta a adição de múltiplos clientes no futuro, como um painel de controle (dashboard), por exemplo.

## Funções Exportadas

### `getClient(apiKey)`

Esta função busca e retorna um cliente do registro `API_CLIENTS` com base na `apiKey` fornecida.

- **Parâmetros:**
    - `apiKey` (string): A chave de API a ser validada.
- **Retorno:**
    - Retorna o objeto do cliente (`{ name, secret }`) se a chave for encontrada.
    - Retorna `null` se nenhuma correspondência for encontrada.

## Uso no Sistema

Este módulo é utilizado principalmente pelo middleware de autenticação (`src/middlewares/autenticate.js`) para verificar a validade de uma chave de API antes de permitir o acesso a rotas protegidas.
