# `src/config/mongo.js`

Este módulo é responsável por estabelecer e gerenciar a conexão com o banco de dados MongoDB, garantindo que a aplicação tenha uma conexão robusta e resiliente.

## Visão Geral

O arquivo define a função `connectMongo`, que lida com todos os aspectos da conexão, incluindo:
1.  Carregamento de certificados TLS para uma conexão segura.
2.  Configuração de um pool de conexões otimizado.
3.  Implementação de uma lógica de retentativas (retry) para lidar com falhas transitórias na inicialização.
4.  Monitoramento de eventos de conexão/desconexão.

## Dependências

-   `mongoose`: Principal ODM (Object Data Modeling) para interagir com o MongoDB.
-   `path`: Utilitário do Node.js para manipular caminhos de arquivos.
-   `fs`: Módulo de sistema de arquivos do Node.js, usado para verificar a existência dos certificados.

## Lógica de Conexão

### 1. Verificação de Certificados

Antes de tentar a conexão, o script verifica se os arquivos de certificado necessários (`ca-certificate.crt`, `certificate.pem`, `private-key.key`) existem no diretório `./certs/mongo/`. Se algum arquivo estiver faltando, uma exceção é lançada, interrompendo a inicialização do servidor.

### 2. Opções de Conexão

Um objeto `options` é configurado para a conexão com o Mongoose, com destaque para:
-   **Segurança (TLS):** `tls: true` e os caminhos para os certificados garantem que a comunicação com o banco de dados seja criptografada.
-   **Timeouts:** `serverSelectionTimeoutMS` e `connectTimeoutMS` evitam que a aplicação fique "presa" indefinidamente durante uma tentativa de conexão.
-   **Pool de Conexões:**
    -   `maxPoolSize` e `minPoolSize` controlam o número de conexões abertas, otimizando a performance ao reutilizar conexões.
    -   `maxIdleTimeMS` fecha conexões inativas para economizar recursos.
-   **Heartbeat:** `heartbeatFrequencyMS` permite que a aplicação detecte proativamente se a conexão com o banco de dados foi perdida.

### 3. Lógica de Retentativas (Retry)

A conexão não é uma tentativa única. O código implementa um loop `for` que tenta se conectar até `maxRetries` (5 vezes) com um intervalo de `retryDelay` (3 segundos) entre as tentativas. Isso torna a aplicação mais resiliente a problemas temporários de rede ou do banco de dados durante a inicialização.

### 4. Monitoramento de Eventos

Listeners de eventos do Mongoose são registrados para logar mensagens no console quando a aplicação se desconecta ou reconecta ao MongoDB, facilitando o monitoramento do estado da conexão em tempo real.

## Funções Exportadas

### `connectMongo()`

-   **Método:** `async`
-   **Descrição:** Executa todo o processo de conexão descrito acima. É uma função `async`, então ela deve ser aguardada (`await`) quando chamada no `startServer` do `index.js`.
-   **Retorno:** Retorna uma `Promise` que resolve quando a conexão é bem-sucedida.
-   **Erros:** Lança uma exceção se não conseguir se conectar após todas as retentativas, o que causa a falha na inicialização do servidor.

## Uso no Sistema

A função `connectMongo` é chamada uma vez, durante a inicialização do servidor (no arquivo `index.js`), para garantir que a conexão com o banco de dados esteja ativa antes que a API comece a aceitar requisições.
