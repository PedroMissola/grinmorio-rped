# `src/config/redis.js`

Este módulo gerencia a conexão com o servidor Redis, que é usado para dados efêmeros e de alta velocidade, como estado de sessão, caches e o histórico recente de rolagens.

## Visão Geral

O arquivo exporta duas funções principais: `connectRedis` para estabelecer a conexão e `getRedisClient` para obter a instância do cliente Redis já conectado em outras partes da aplicação. A conexão é configurada para ser segura (via TLS) e resiliente.

## Dependências

-   `ioredis`: Um cliente Redis para Node.js robusto e de alta performance.
-   `fs`: Módulo de sistema de arquivos, para ler os certificados.
-   `path`: Utilitário para manipular caminhos de arquivos.

## Variáveis Globais

### `redisClient`

Uma variável no escopo do módulo que armazena a instância do cliente `ioredis` após a conexão ser estabelecida.

## Lógica de Conexão

### 1. Carregamento de Certificados

Assim como no `mongo.js`, a primeira etapa é carregar os certificados TLS (`ca-certificate.crt`, `certificate.pem`, `private-key.key`) do diretório `./certs/redis/`. Uma função auxiliar `getCertBuffer` é usada para ler os arquivos. Se algum certificado não for encontrado, uma exceção é lançada.

### 2. Opções de Conexão (`redisOptions`)

Um objeto de configuração detalhado é criado para a instância do `ioredis`:
-   **Segurança (TLS):** O objeto `tlsConfig` contém os buffers dos certificados. `rejectUnauthorized: true` garante que a identidade do servidor seja validada.
-   **Resiliência:**
    -   `maxRetriesPerRequest`: Define o número máximo de tentativas para um comando individual que falhou.
    -   `retryStrategy`: Uma função customizada que define a lógica de reconexão. Ela tenta reconectar até 10 vezes com um delay crescente, tornando a aplicação mais robusta a falhas temporárias de conexão com o Redis.
-   **Performance:** `lazyConnect: true` é uma otimização importante. Significa que o cliente não tenta se conectar no momento da sua instanciação (`new Redis(...)`), mas apenas quando o método `.connect()` é chamado explicitamente.

### 3. Instanciação e Conexão

1.  O cliente Redis é instanciado com a URI do Redis (de `process.env.REDIS_URI`) e as `redisOptions`.
2.  Listeners de eventos são registrados para `error` e `reconnecting`, fornecendo logs úteis sobre o estado da conexão.
3.  O método `await redisClient.connect()` é chamado. Por causa do `lazyConnect`, é neste ponto que a conexão realmente acontece. O `await` garante que a função `connectRedis` só termine após a conexão ser bem-sucedida.

## Funções Exportadas

### `connectRedis()`

-   **Método:** `async`
-   **Descrição:** Orquestra todo o processo de conexão com o Redis. Deve ser chamada e aguardada (`await`) na inicialização do servidor.
-   **Erros:** Lança uma exceção se os certificados não forem encontrados ou se a conexão inicial falhar.

### `getRedisClient()`

-   **Descrição:** Uma função getter que retorna a instância do cliente `redisClient`.
-   **Erros:** Lança uma exceção se for chamada antes de `connectRedis` ter estabelecido a conexão, garantindo que nenhuma parte da aplicação tente usar um cliente não inicializado.

## Uso no Sistema

-   `connectRedis()`: Chamada no `index.js` durante a inicialização do servidor.
-   `getRedisClient()`: Usada em toda a aplicação (principalmente nos `services`) para obter o cliente Redis e executar comandos como `get`, `set`, `lpush`, `pipeline`, etc.
