# `src/config/rpedConstants.js`

Este arquivo é um dos mais críticos para a lógica de negócio do sistema RPED (Rolagem Ponderada com Engenharia Dinâmica). Ele centraliza todas as constantes, limiares e taxas que governam os algoritmos de equilíbrio.

## Visão Geral

A principal função deste arquivo é fornecer um local único e de fácil acesso para ajustar o comportamento dos mecanismos de Karma, Resgate e Sorte. Alterar os valores aqui tem um impacto direto e global em como as rolagens de dados são ponderadas e corrigidas.

A organização das constantes segue os subsistemas do RPED:
-   `KARMA_*`: Parâmetros para o sistema de punição por "sorte excessiva".
-   `RESCUE_*`: Limiares para o "Modo Resgate" e seu controle de histerese.
-   `LUCK_*`: Configurações da sorte diária dos jogadores.
-   `HISTORY_*`: Parâmetros para o armazenamento de históricos de rolagens no Redis.
-   `DICE_*`: Limites para os tipos de dados aceitos pelo sistema.

## Constantes Detalhadas

### Sistema de Karma (`KARMA_*`)

-   `KARMA_DELTA_THRESHOLD`: Define o quão maior a média de um jogador precisa ser em relação à média da guilda para que ele se torne elegível à punição do Karma. (Valor: `0.15` ou 15%).
-   `KARMA_HIGH_ROLL_THRESHOLD`: Uma rolagem é considerada "alta" (e portanto, passível de Karma) se seu valor for maior que esta porcentagem do tamanho do dado. (Valor: `0.8` ou 80%).
-   `KARMA_PENALTY_RATE`: A porcentagem de redução aplicada a uma rolagem quando o Karma é ativado. (Valor: `0.2` ou 20%).

### Modo Resgate (`RESCUE_*`)

-   `RESCUE_ACTIVATION_THRESHOLD`: O "Modo Resgate" é ativado para toda a guilda se a média global de rolagens cair abaixo deste valor. (Valor: `0.215`).
-   `RESCUE_DEACTIVATION_THRESHOLD`: Para evitar oscilações, o Modo Resgate só é desativado quando a média sobe para um valor significativamente maior, acima deste limiar. Este mecanismo é chamado de **histerese**. (Valor: `0.275`).
-   `RESCUE_MAX_BONUS_RATE`: A porcentagem máxima do tamanho do dado que pode ser adicionada como bônus durante o Modo Resgate. (Valor: `0.25` ou 25%).
-   `RESCUE_MIN_BONUS`: Um bônus mínimo garantido em rolagens durante o Modo Resgate. (Valor: `1`).

### Sorte Diária (`LUCK_*`)

-   `LUCK_MIN` / `LUCK_MAX`: O intervalo (inclusivo) para o nível de sorte diária de um jogador. (Valores: `0` e `10`).
-   `LUCK_TTL_SECONDS`: O tempo de vida (Time To Live) da chave de sorte diária no Redis, em segundos. (Valor: `86400`, equivalente a 24 horas).

### Histórico Redis (`HISTORY_*`)

-   `HISTORY_USER_SIZE`: O número máximo de rolagens recentes de um usuário que são mantidas no Redis para cálculo de sua média individual. (Valor: `9`).
-   `HISTORY_GUILD_SIZE`: O número máximo de rolagens recentes da guilda que são mantidas no Redis para cálculo da média global. (Valor: `99`).
-   `HISTORY_DEFAULT_AVERAGE`: Um valor de média padrão utilizado quando um jogador ou guilda ainda não possui histórico de rolagens. (Valor: `0.5`).

### Limites do Dado (`DICE_*`)

-   `DICE_MIN_SIZE` / `DICE_MAX_SIZE`: O menor e o maior dado (em número de faces) que o sistema aceita para uma rolagem. (Valores: `4` e `1000`).

## Uso no Sistema

Estas constantes são importadas e utilizadas massivamente no `rpedService.js`, que contém a implementação central dos algoritmos de equilíbrio.
