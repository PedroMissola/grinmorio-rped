# `src/controllers/analyticsController.js`

Este arquivo define os `controllers` para endpoints da API relacionados ao registro de logs e eventos de analytics. Sua principal responsabilidade é receber dados de log, formatá-los e persisti-los no MongoDB.

## Visão Geral

O controller expõe duas funções principais, `recordEvent` e `saveLog`, que são mapeadas para rotas específicas da API. Ambas utilizam funções auxiliares internas para evitar duplicação de código e manter a clareza.

## Dependências

-   `../models/Log`: O modelo Mongoose para a coleção `logs` no banco de dados.
-   `../utils/AppError`: A classe de erro customizada para lidar com erros operacionais.

## Funções Auxiliares Internas

### `createLogEntry(fields)`

-   **Método:** `async`
-   **Descrição:** Uma função wrapper simples que recebe um objeto de campos e cria uma nova entrada no banco de dados usando `Log.create()`. Centraliza a lógica de persistência.

### `extractIdentifiers(details)`

-   **Descrição:** Uma função utilitária para extrair `guildId` e `userId` de um objeto `details`. Ela é projetada para lidar com dois formatos de dados que podem vir da API: um onde os IDs estão na raiz do objeto `details`, e outro onde eles estão aninhados dentro de um objeto `interaction`. Isso confere flexibilidade aos clientes da API.
-   **Retorno:** Retorna um objeto `{ guildId, userId }`, com os valores sendo `null` se não forem encontrados.

## Controladores Exportados

### `recordEvent(req, res, next)`

-   **Rota Sugerida:** `POST /api/stats/record`
-   **Descrição:** Endpoint para registrar um evento de analytics genérico (ex: 'bot_started', 'guild_joined').
-   **Lógica:**
    1.  Extrai `event` e `details` do corpo da requisição (`req.body`).
    2.  Usa `extractIdentifiers` para obter os IDs de guilda e usuário.
    3.  Chama `createLogEntry` para criar o documento no MongoDB com `level` 'ANALYTICS'.
    4.  Responde com `201 Created` e uma mensagem de sucesso.
    5.  Qualquer erro durante o processo é capturado e passado para o middleware de erro global via `next(error)`.

### `saveLog(req, res, next)`

-   **Rota Sugerida:** `POST /api/logs`
-   **Descrição:** Endpoint mais genérico para salvar logs de sistema, que podem ser de diferentes níveis (`INFO`, `WARN`, `ERROR`, etc.).
-   **Lógica:**
    1.  Extrai `level`, `message`, e `details` do corpo da requisição.
    2.  Usa `extractIdentifiers` para obter os IDs.
    3.  Chama `createLogEntry` para persistir o log com o `evento` 'SYSTEM_LOG'.
    4.  Responde com `201 Created` e uma mensagem de sucesso.
    5.  Delega o tratamento de erros para o middleware global.

## Boas Práticas Implementadas

-   **Single Responsibility:** Cada função tem uma responsabilidade clara (extrair dados, persistir dados, controlar a rota).
-   **Don't Repeat Yourself (DRY):** Funções auxiliares como `createLogEntry` e `extractIdentifiers` evitam a repetição de código.
-   **Error Handling Centralizado:** Em vez de tratar erros e enviar respostas de erro diretamente, os `controllers` usam `try...catch` para delegar todos os erros ao middleware de erro global, mantendo o código do controller mais limpo.
