# `src/controllers/guildController.js`

Este arquivo contém os `controllers` responsáveis por gerenciar as configurações específicas de cada guilda (servidor do Discord).

## Visão Geral

Ele expõe endpoints que permitem a um cliente (como o bot do Discord) buscar e atualizar as configurações de uma guilda específica, como prefixo de comando, canais de rolagem permitidos, etc.

## Dependências

-   `../models/Guild`: O modelo Mongoose para a coleção `guilds`.
-   `../utils/AppError`: A classe de erro customizada.

## Controladores Exportados

### `getGuildSettings(req, res, next)`

-   **Rota Sugerida:** `GET /api/guilds/:guildId/settings`
-   **Descrição:** Busca e retorna as configurações de uma guilda específica.
-   **Lógica:**
    1.  Extrai o `guildId` dos parâmetros da rota (`req.params`).
    2.  Busca a guilda no banco de dados usando `Guild.findOne({ guildId })`.
    3.  Se a guilda não for encontrada, lança um `AppError` com status `404 Not Found`.
    4.  Se encontrada, responde com `200 OK` e envia o subdocumento `guild.configs` no corpo da resposta.
    5.  Erros de banco de dados são capturados e passados ao middleware de erro global.

### `updateGuildSettings(req, res, next)`

-   **Rota Sugerida:** `PUT /api/guilds/:guildId/settings`
-   **Descrição:** Atualiza as configurações de uma guilda.
-   **Lógica:**
    1.  Extrai o `guildId` dos parâmetros da rota e o objeto `settings` do corpo da requisição (`req.body`).
    2.  Valida se o objeto `settings` foi fornecido; caso contrário, lança um `AppError` com status `400 Bad Request`.
    3.  Constrói um objeto `updateData` apenas com as configurações que foram de fato enviadas na requisição. Isso evita a sobrescrita de campos não intencionais. A notação `configs.prefix` é usada para atualizar campos aninhados no subdocumento `configs`.
    4.  Usa `Guild.findOneAndUpdate` para aplicar as atualizações:
        -   `{ guildId }`: O filtro para encontrar o documento correto.
        -   `{ $set: updateData }`: O operador do MongoDB para atualizar os campos especificados.
        -   `{ new: true, upsert: true, setDefaultsOnInsert: true }`: Opções importantes:
            -   `new: true`: Retorna o documento *após* a atualização.
            -   `upsert: true`: Cria um novo documento se nenhuma guilda com o `guildId` for encontrada.
            -   `setDefaultsOnInsert: true`: Garante que, se um novo documento for criado, os valores padrão definidos no `GuildSchema` sejam aplicados.
    5.  Responde com `200 OK`, uma mensagem de sucesso e as configurações atualizadas.
    6.  Delega o tratamento de erros ao middleware global.
