# `src/controllers/rollController.js`

Este é o `controller` para o endpoint mais importante da aplicação: o processamento de rolagens de dados.

## Visão Geral

Sua responsabilidade é muito focada: receber os dados de uma requisição de rolagem, passá-los para o `rollService` (que contém a lógica complexa) e formatar a resposta de volta para o cliente.

## Dependências

-   `../services/rollService`: O serviço que encapsula toda a lógica de negócio do sistema RPED (cálculo de sorte, karma, resgate, etc.).

## Controladores Exportados

### `postRoll(req, res, next)`

-   **Rota Sugerida:** `POST /api/roll`
-   **Descrição:** Orquestra a execução de uma nova rolagem de dado.
-   **Lógica:**
    1.  Extrai `guildId`, `usuarioId`, `tamanhoDado`, e `modificador` do corpo da requisição (`req.body`). É importante notar que, conforme o comentário no código, espera-se que um middleware de validação (como o `Zod`) já tenha sido executado antes, garantindo que esses dados existam e estejam nos tipos corretos.
    2.  Chama `rollService.executeRoll()` com os dados da rolagem. Toda a complexidade é delegada a este serviço.
    3.  Aguarda o resultado do serviço, que é um objeto contendo todos os detalhes da rolagem (resultado final, bônus, etc.).
    4.  Responde com `200 OK` e um corpo de resposta JSON bem estruturado, contendo os dados originais da requisição e o resultado retornado pelo serviço.
    5.  Qualquer erro lançado pelo `rollService` (seja um erro operacional `AppError` ou um bug inesperado) é capturado e passado para o middleware de erro global.

## Ponto de Destaque

Este controller é um excelente exemplo do padrão "Thin Controller, Fat Service". O controller em si é muito simples e legível. Ele não sabe *como* uma rolagem é calculada, apenas para quem ele deve pedir para fazer o cálculo (`rollService`). Isso torna o código mais organizado, fácil de testar e de dar manutenção.
