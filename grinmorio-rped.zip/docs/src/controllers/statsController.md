# `src/controllers/statsController.js`

Este arquivo agrupa os `controllers` responsáveis por expor endpoints de estatísticas, tanto globais (do bot) quanto específicas (por guilda ou por usuário).

## Visão Geral

O objetivo deste módulo é consultar o banco de dados, agregar informações de diferentes `Models` e formatá-las em respostas JSON coesas que possam ser consumidas por um frontend ou pelo bot para exibir fichas e painéis de estatísticas.

## Dependências

-   `../models/User`: Modelo Mongoose para usuários.
-   `../models/Guild`: Modelo Mongoose para guildas.
-   `../models/Rolagem`: Modelo Mongoose para o log de rolagens individuais.
-   `../models/Rped`: Modelo Mongoose para dados globais do sistema RPED.
-   `../utils/AppError`: Classe de erro customizada.

## Controladores Exportados

### `getBotStats(req, res, next)`

-   **Rota Sugerida:** `GET /api/stats/bot`
-   **Descrição:** Fornece uma visão geral das estatísticas globais do sistema.
-   **Lógica:**
    1.  Realiza múltiplas consultas ao banco de dados para obter:
        -   Contagem total de usuários (`User.countDocuments()`).
        -   Contagem total de guildas (`Guild.countDocuments()`).
        -   Contagem de rolagens nos últimos 30 dias (considerando o TTL dos logs de rolagem).
    2.  Busca o documento `GRINMORIO_CORE` do modelo `Rped` para obter estatísticas acumuladas, como o total de intervenções de Karma e Resgate.
    3.  Inclui um tratamento para o caso de o documento `Rped` ainda não existir (ex: primeira vez que o sistema roda), retornando valores zerados.
    4.  Combina todos os dados em um único objeto `stats` e o retorna como resposta JSON.
    5.  Delega o tratamento de erros ao middleware global.

### `getGuildStats(req, res, next)`

-   **Rota Sugerida:** `GET /api/stats/guild/:guildId`
-   **Descrição:** Compila e retorna as estatísticas de uma guilda específica.
-   **Lógica:**
    1.  Obtém o `guildId` dos parâmetros da rota.
    2.  Busca o documento da guilda correspondente. Se não encontrar, lança um `AppError` 404.
    3.  Itera sobre o array `guild.usuarios`, que contém um snapshot das estatísticas dos jogadores daquela guilda, para somar os totais de rolagens, sucessos e falhas críticas.
    4.  Calcula a taxa de acertos críticos.
    5.  Retorna os dados compilados em uma resposta JSON.
    6.  Delega o tratamento de erros ao middleware global.

### `getUserStats(req, res, next)`

-   **Rota Sugerida:** `GET /api/stats/user/:userId`
-   **Descrição:** Monta uma "ficha de jogador", com suas estatísticas e histórico recente de rolagens.
-   **Lógica:**
    1.  Obtém o `userId` dos parâmetros da rota.
    2.  Realiza duas consultas em paralelo (implicitamente):
        -   `User.findOne({ userId })` para buscar as estatísticas acumuladas do jogador.
        -   `Rolagem.find(...)` para buscar as últimas 10 rolagens desse usuário, ordenadas pela data mais recente.
    3.  Verifica se o usuário existe ou se tem alguma atividade. Se ambas as consultas não retornarem nada, lança um `AppError` 404.
    4.  Formata o `historicoRecente` em um formato mais limpo e legível para o cliente.
    5.  Retorna as estatísticas combinadas (dados do perfil e histórico) como uma resposta JSON.
    6.  Delega o tratamento de erros ao middleware global.
