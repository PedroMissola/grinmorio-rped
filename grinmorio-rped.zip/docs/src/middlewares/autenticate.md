# `src/middlewares/autenticate.js`

Este arquivo define o middleware de autenticação principal da API, que protege os endpoints contra acesso não autorizado.

## Visão Geral

O middleware `authenticate` implementa uma estratégia de autenticação baseada em **HMAC (Hash-based Message Authentication Code)**. Este método garante que:
1.  O remetente da requisição é quem ele diz ser (autenticidade).
2.  O corpo da requisição não foi alterado no caminho (integridade).
3.  A requisição não pode ser simplesmente "copiada e colada" para ser reutilizada mais tarde (proteção contra ataques de replay).

## Dependências

-   `crypto`: Módulo nativo do Node.js para operações criptográficas, como a criação do HMAC.
-   `../config/apiKeys`: Módulo que gerencia os clientes de API autorizados e seus segredos.

## Lógica do Middleware

O middleware executa uma série de validações em sequência. Se qualquer uma delas falhar, ele interrompe o fluxo e retorna uma resposta `401 Unauthorized`.

### Headers Esperados

Para uma requisição ser considerada válida, ela deve conter os seguintes headers HTTP:
-   `x-api-key`: A chave de API do cliente.
-   `x-timestamp`: O timestamp Unix (em milissegundos) de quando a requisição foi criada.
-   `x-signature`: A assinatura HMAC gerada pelo cliente.

### Passos da Validação

1.  **Presença dos Headers:** Verifica se todos os três headers (`x-api-key`, `x-timestamp`, `x-signature`) estão presentes.
2.  **Validação da API Key:** Usa a função `getClient(apiKey)` para verificar se a `apiKey` recebida corresponde a um cliente registrado no sistema.
3.  **Validação do Timestamp (Proteção contra Replay Attack):**
    -   Verifica se o `timestamp` recebido está dentro de uma janela de tolerância (`TIMESTAMP_TOLERANCE_MS`, definida como 5 minutos).
    -   Isso impede que um atacante capture uma requisição válida e a reenvie indefinidamente. Após 5 minutos, a mesma requisição se torna inválida.
4.  **Validação da Assinatura (Autenticidade e Integridade):**
    -   Este é o passo mais importante. O middleware recria a assinatura HMAC do lado do servidor exatamente da mesma forma que o cliente deveria ter feito.
    -   O payload que é assinado consiste no `timestamp` + um ponto (`.`) + o corpo (`body`) da requisição em formato de string JSON.
    -   A assinatura é gerada usando o algoritmo `HMAC-SHA256` com o segredo do cliente (obtido no passo 2).
    -   A assinatura gerada no servidor (`expectedSignature`) é comparada com a assinatura enviada pelo cliente (`signature`).
    -   **Ponto de Segurança Importante:** A comparação é feita usando `crypto.timingSafeEqual`, uma função que leva um tempo constante para ser executada, independentemente de onde a diferença entre as strings ocorre. Isso previne "timing attacks", onde um atacante poderia tentar adivinhar a assinatura medindo o tempo de resposta do servidor.
5.  **Sucesso:** Se todas as validações passarem, o middleware anexa as informações do cliente (`req.client`) ao objeto da requisição, para que possam ser usadas posteriormente (por exemplo, em logs), e chama `next()` para passar o controle para o próximo middleware ou para o controller da rota.
