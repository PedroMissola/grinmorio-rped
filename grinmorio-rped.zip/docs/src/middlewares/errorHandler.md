# `src/middlewares/errorHandler.js`

Este arquivo define o middleware de tratamento de erros global da aplicação, uma peça central para garantir que todos os erros sejam tratados de forma consistente e segura.

## Visão Geral

O `errorHandler` é o último middleware na cadeia do Express. Ele "captura" qualquer erro que ocorra nos `controllers` ou em middlewares anteriores, que são passados através da função `next(error)`. Sua função é formatar uma resposta de erro apropriada para o cliente e registrar o erro no servidor para depuração.

## Dependências

-   `../utils/AppError`: A classe de erro customizada para erros operacionais.

## Funções

### `normalizeError(err)`

-   **Descrição:** Esta função auxiliar é um "tradutor" de erros. Ela inspeciona um objeto de erro (`err`) e, se ele for um erro conhecido de uma biblioteca de terceiros (como Mongoose ou o parser de body do Express), ela o converte em um `AppError` com um status HTTP e uma mensagem mais amigáveis e semânticas.
-   **Mapeamentos:**
    -   **`ValidationError` (Mongoose):** Erro de validação de schema (ex: campo obrigatório faltando). Converte para `400 Bad Request`.
    -   **`err.code === 11000` (MongoDB):** Violação de índice único (tentativa de inserir um valor duplicado). Converte para `409 Conflict`.
    -   **`CastError` (Mongoose):** Falha ao converter um tipo, como um ID inválido. Converte para `400 Bad Request`.
    -   **`entity.parse.failed` (body-parser):** Erro de sintaxe no JSON enviado no corpo da requisição. Converte para `400 Bad Request`.
    -   **`entity.too.large` (body-parser):** O corpo da requisição excede o limite de tamanho definido. Converte para `413 Payload Too Large`.
-   **Retorno:** Se o erro for um dos tipos conhecidos, retorna um novo `AppError`. Caso contrário, retorna o erro original sem modificação.

### `errorHandler(err, req, res, next)`

-   **Descrição:** O middleware principal de tratamento de erros.
-   **Lógica:**
    1.  **Normalização:** Primeiro, passa o erro recebido pela função `normalizeError` para garantir que ele esteja no formato `AppError`, se aplicável.
    2.  **Identificação do Erro:** Determina o `statusCode` (padrão 500) e se o erro é `isOperational` (um erro de negócio previsto, como "Usuário não encontrado"). Erros que não são `AppError` são considerados não operacionais (bugs).
    3.  **Logging Inteligente:**
        -   Se o erro for **operacional**, ele registra um `console.warn` com uma mensagem curta. Esses erros são esperados e não indicam um bug no sistema.
        -   Se o erro for **não operacional** (um bug), ele registra um `console.error` com o `stack trace` completo, fornecendo o máximo de informação para depuração.
    4.  **Resposta ao Cliente:**
        -   Envia a resposta HTTP com o `statusCode` apropriado.
        -   Se o erro for **operacional**, a mensagem de erro específica (`err.message`) é enviada no corpo da resposta JSON.
        -   Se for um **bug**, uma mensagem genérica (`'Erro interno no servidor.'`) é enviada para evitar vazar detalhes da implementação ou do `stack trace` para o cliente, o que seria uma falha de segurança.

## Uso no Sistema

O `errorHandler` é registrado no `index.js` usando `app.use(errorHandler)`, e deve ser a **última** chamada de `app.use` para que possa capturar erros de todas as rotas e middlewares registrados antes dele.
