# `src/middlewares/rateLimiters.js`

Este arquivo define e configura os middlewares de **Rate Limiting** (limitação de taxa de requisições) para diferentes endpoints da API, protegendo o sistema contra abuso, ataques de negação de serviço (DoS) e uso excessivo de recursos.

## Visão Geral

A estratégia adotada é criar limitadores específicos para diferentes tipos de rotas, em vez de um único limitador global com regras genéricas. Isso permite ajustar a proteção de acordo com a sensibilidade e o custo de cada operação. Por exemplo, a rota de rolagem, que é computacionalmente mais cara e modifica o estado no Redis, tem um limite mais rígido do que a rota para atualizar configurações.

## Dependências

-   `express-rate-limit`: A biblioteca utilizada para criar os middlewares de limitação de taxa.

## Lógica e Configuração

### `clientKeyGenerator(req)`

-   **Descrição:** Esta é uma função chave para o funcionamento dos limitadores. Ela determina como um "cliente" é identificado para a contagem de requisições.
-   **Lógica:**
    1.  Tenta obter a `apiKey` do objeto `req.client`, que é anexado pelo middleware de autenticação (`autenticate.js`) se a requisição for bem-sucedida.
    2.  Se `req.client` não existir (ex: a rota não é protegida ou a autenticação falhou), ele usa o endereço de IP do requisitante (`req.ip`) como um fallback.
-   **Importância:** Usar a `apiKey` como identificador é mais preciso e justo do que usar o IP, especialmente em cenários onde múltiplos bots podem estar rodando atrás do mesmo endereço de IP (como em uma mesma máquina ou rede).

### Limitadores Específicos

Todos os limitadores são criados usando a função `rateLimit` e compartilham algumas configurações padrão:
-   `keyGenerator: clientKeyGenerator`: Usa a função descrita acima para identificar clientes.
-   `standardHeaders: true`: Adiciona headers HTTP padronizados na resposta (ex: `RateLimit-Limit`, `RateLimit-Remaining`), informando o cliente sobre seu status de limitação.
-   `legacyHeaders: false`: Desativa headers mais antigos e não padronizados.
-   `message`: Define a mensagem de erro JSON que é enviada quando o limite é excedido (resultando em um status `429 Too Many Requests`).

#### `rollLimiter`

-   **Rotas Alvo:** Endpoint de rolagem (`POST /api/roll`).
-   **Configuração:** `max: 10` requisições a cada `windowMs: 10 * 1000` (10 segundos).
-   **Justificativa:** É um limite restrito para proteger a integridade do `rpedService` e do Redis, que são intensivos em escrita. Um bot legítimo raramente precisa fazer mais de 10 rolagens em 10 segundos.

#### `guildSettingsLimiter`

-   **Rotas Alvo:** Endpoints de configuração de guilda (`GET` e `PUT` em `/api/guilds/...`).
-   **Configuração:** `max: 20` requisições por `windowMs: 60 * 1000` (1 minuto).
-   **Justificativa:** É uma operação administrativa, menos frequente. O limite é mais tolerante, mas ainda previne que um script malicioso tente atualizar as configurações em um loop rápido.

#### `analyticsLimiter`

-   **Rotas Alvo:** Endpoints de analytics e logs (`POST /api/stats/record`, `POST /api/logs`).
-   **Configuração:** `max: 50` requisições por `windowMs: 60 * 1000` (1 minuto).
-   **Justificativa:** Um limite moderado, que permite um volume razoável de logs sem sobrecarregar o endpoint de escrita no banco de dados.

## Uso no Sistema

Estes limitadores são importados e aplicados a rotas específicas no `index.js` ou, mais comumente, nos arquivos de rotas (`src/routes/*.js`), garantindo que a proteção seja aplicada apenas onde é necessária.

Exemplo de uso em um arquivo de rotas:
```javascript
const express = require('express');
const router = express.Router();
const { postRoll } = require('../controllers/rollController');
const { rollLimiter } = require('../middlewares/rateLimiters');

// Aplica o rate limiter apenas a esta rota
router.post('/roll', rollLimiter, postRoll);

module.exports = router;
```
