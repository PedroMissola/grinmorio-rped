# `src/middlewares/sanitize.js`

Este arquivo fornece middlewares de **sanitização** (limpeza de dados) para proteger a aplicação contra ataques de **NoSQL Injection**.

## Visão Geral

O MongoDB, por ser um banco de dados NoSQL, usa operadores especiais que começam com `$` (como `$gt`, `$ne`, `$where`) em suas queries. Se um atacante conseguir injetar esses operadores em dados que são usados para construir uma consulta ao banco (como `req.params` ou `req.body`), ele pode, potencialmente, alterar a lógica da query para extrair dados não autorizados ou até mesmo modificar/apagar informações.

Estes middlewares servem como uma camada de defesa para prevenir que tais caracteres maliciosos cheguem aos `controllers` e, consequentemente, às consultas ao banco de dados.

## Funções Exportadas

### `sanitizeParams(req, res, next)`

-   **Descrição:** Um middleware projetado para validar os parâmetros da rota (`req.params`).
-   **Lógica:**
    1.  Define uma expressão regular (`DANGEROUS_CHARS`) que busca por caracteres comumente usados em operadores do MongoDB: `$`, `{`, `}`, `[`, `]`.
    2.  Itera sobre cada par chave-valor em `req.params`.
    3.  Se o valor for uma string e contiver qualquer um dos caracteres perigosos, o middleware imediatamente interrompe a requisição, retornando um erro `400 Bad Request`.
    4.  Se todos os parâmetros forem "limpos", ele chama `next()` para continuar o fluxo da requisição.
-   **Uso:** Este middleware deve ser aplicado a rotas que usam parâmetros dinâmicos, como `router.get('/:id', sanitizeParams, controller.getById)`.

### `sanitizeBody(req, res, next)`

-   **Descrição:** Um middleware mais robusto que sanitiza o corpo da requisição (`req.body`).
-   **Lógica:**
    1.  Ele utiliza uma função auxiliar recursiva, `deepSanitize`, que "caminha" por todo o objeto `req.body`.
    2.  A função `deepSanitize` reconstrói o objeto, mas **exclui** qualquer chave (propriedade) que comece com o caractere `$`.
    3.  A recursão garante que a sanitização funcione em objetos aninhados e arrays de objetos.
    4.  Após a limpeza, o `req.body` sanitizado substitui o original.
    5.  Chama `next()` para passar o controle adiante.
-   **Uso:** Este middleware é aplicado globalmente no `index.js` logo no início da cadeia, garantindo que todas as requisições que possuem um corpo (`POST`, `PUT`, `PATCH`) sejam sanitizadas antes mesmo da autenticação ou validação de schema.

## Estratégia de Defesa em Camadas

É importante notar que a sanitização aqui é uma **camada adicional** de segurança. A principal defesa contra NoSQL Injection é o uso de um **ODM como o Mongoose**, que, por padrão, já sanitiza os inputs ao construir as queries. Além disso, a validação de schema (com uma biblioteca como Zod, por exemplo) também ajuda a garantir que a estrutura dos dados seja a esperada.

Este arquivo implementa o princípio de **"defesa em profundidade"**: mesmo que uma camada de proteção falhe, existem outras para mitigar o ataque.
