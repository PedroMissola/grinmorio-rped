# `src/middlewares/validate.js`

Este arquivo define um middleware de validação de dados genérico e reutilizável, que usa a biblioteca **Zod** para garantir a integridade e o formato dos dados que chegam à API.

## Visão Geral

O objetivo deste middleware é validar o corpo (`body`) de uma requisição HTTP contra um "schema" (um conjunto de regras) predefinido. Se os dados forem válidos, a requisição continua; se forem inválidos, uma resposta de erro clara e detalhada é retornada imediatamente, antes que a lógica de negócio do `controller` seja executada.

## Dependências

-   `zod`: Uma biblioteca de declaração e validação de schemas para TypeScript e JavaScript.

## Lógica do Middleware

### `validate(schema)`

-   **Descrição:** Esta é uma **função de ordem superior** (higher-order function). Ela não é um middleware em si, mas uma função que **retorna** um middleware configurado. Ela recebe um `schema` Zod como argumento.
-   **Parâmetros:**
    -   `schema` (`ZodSchema`): Um objeto de schema criado com a biblioteca Zod. Este schema define a "forma" esperada do `req.body`.
-   **Retorno:** Uma função de middleware do Express `(req, res, next)`.

#### O Middleware Retornado

1.  **Validação:** Ele usa o método `schema.safeParse(req.body)`. `safeParse` é preferível a `parse` porque ele não lança uma exceção em caso de falha, mas retorna um objeto de resultado, o que permite um controle de fluxo mais explícito.

2.  **Cenário de Falha:**
    -   Se `result.success` for `false`, significa que a validação falhou.
    -   O middleware formata os erros retornados pelo Zod em um array mais amigável, contendo o `campo` e a `mensagem` de cada erro.
    -   Ele interrompe a requisição e responde com um status `400 Bad Request`, incluindo a lista de erros detalhados. Isso é extremamente útil para o cliente da API, que sabe exatamente quais campos precisam ser corrigidos.

3.  **Cenário de Sucesso:**
    -   Se `result.success` for `true`, os dados são válidos.
    -   **Ponto Crucial:** O `req.body` original é **substituído por `result.data`**. `result.data` contém os dados após o Zod ter aplicado qualquer **coerção de tipo** definida no schema (por exemplo, converter uma string `"123"` para o número `123`). Isso garante que o `controller` subsequente receba os dados já limpos e nos tipos corretos, simplificando a lógica do controller.
    -   A função `next()` é chamada para passar o controle para o próximo middleware ou para o controller da rota.

## Uso no Sistema

O middleware `validate` é usado nos arquivos de rotas (`src/routes/*.js`) para proteger os endpoints que recebem dados no corpo da requisição.

**Exemplo de Uso:**

1.  **Definir o Schema (em `src/schemas/rollSchema.js`):**
    ```javascript
    const { z } = require('zod');

    const rollSchema = z.object({
        guildId: z.string().min(1),
        usuarioId: z.string().min(1),
        tamanhoDado: z.number().int().min(4),
        modificador: z.number().int().default(0)
    });

    module.exports = { rollSchema };
    ```

2.  **Aplicar o Middleware na Rota (em `src/routes/rollRoutes.js`):**
    ```javascript
    const express = require('express');
    const router = express.Router();
    const { validate } = require('../middlewares/validate');
    const { rollSchema } = require('../schemas/rollSchema');
    const { postRoll } = require('../controllers/rollController');

    // O middleware de validação é executado antes do controller.
    router.post('/roll', validate(rollSchema), postRoll);

    module.exports = router;
    ```
