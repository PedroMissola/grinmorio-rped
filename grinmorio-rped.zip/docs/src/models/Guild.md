# `src/models/Guild.js`

Este arquivo define o `Schema` do Mongoose para o modelo `Guild`, que representa um servidor do Discord (guilda) no banco de dados.

## Visão Geral

O `guildSchema` armazena todas as informações persistentes relacionadas a uma guilda específica, incluindo suas configurações, cargos administrativos e uma lista de membros com suas estatísticas de rolagens.

## Dependências

-   `mongoose`: A biblioteca ODM para interagir com o MongoDB.

## Schemas Definidos

### `guildMemberSchema`

-   **Descrição:** Este é um **subdocumento** que define a estrutura dos dados de um membro *dentro* de uma guilda. Ele não é um modelo independente, mas parte do `guildSchema`.
-   **Campos:**
    -   `userId` (String, required): O ID do usuário do Discord.
    -   `dadosRolados` (Number): A contagem total de dados que este usuário rolou nesta guilda.
    -   `mediaSorte` (Number): A média de sorte individual do jogador, calculada e atualizada pelo sistema RPED.
    -   `sucessosCriticos` (Number): Contagem de rolagens de sucesso crítico.
    -   `falhasCriticas` (Number): Contagem de rolagens de falha crítica.
-   **Opções:**
    -   `_id: false`: Impede o Mongoose de criar um campo `_id` para cada membro no array, economizando espaço e simplificando a estrutura.

### `guildSchema`

-   **Descrição:** O schema principal para o modelo `Guild`.
-   **Campos Principais:**
    -   `guildId` (String, required, unique, index): O ID da guilda do Discord. É o identificador principal, único e indexado para buscas rápidas.
    -   `configs` (Object): Um objeto aninhado para as configurações da guilda.
        -   `prefix`: O prefixo de comando do bot (ex: `!`).
        -   `rollChannels`: Um array de IDs de canais onde os comandos de rolagem são permitidos. Um valor `'all'` indica que todos os canais são permitidos.
        -   `logChannelId`: O ID do canal para onde os logs de auditoria do bot são enviados.
        -   `statsChannelId`: O ID do canal para postar estatísticas.
    -   `roles` (Object): Um objeto para mapear cargos administrativos.
        -   `adminRoleIds`: Array de IDs de cargos com permissões de administrador do bot.
        -   `mestreRoleIds`: Array de IDs de cargos de "Mestre" do RPG.
    -   `usuarios` (Array de `guildMemberSchema`): Um array que contém os subdocumentos de todos os membros que já interagiram com o bot na guilda.
-   **Opções do Schema:**
    -   `timestamps: true`: Adiciona automaticamente os campos `createdAt` e `updatedAt` a cada documento, registrando quando ele foi criado e quando foi modificado pela última vez.
    -   `versionKey: false`: Remove o campo `__v` que o Mongoose usa para versionamento interno de documentos, simplificando o objeto.

## Modelo Exportado

O arquivo exporta o modelo `Guild` compilado, pronto para ser usado em outras partes da aplicação para criar, ler, atualizar e deletar documentos de guildas.

```javascript
module.exports = mongoose.model('Guild', guildSchema);
```

## Uso no Sistema

O modelo `Guild` é usado principalmente pelos `controllers` (`guildController`, `statsController`) e `services` para:
-   Buscar configurações da guilda.
-   Atualizar configurações.
-   Registrar novos membros.
-   Atualizar as estatísticas de rolagens dos membros.
-   Obter dados para compilar as estatísticas da guilda.
