# `src/models/Log.js`

Este arquivo define o `Schema` do Mongoose para o modelo `Log`, que é usado para auditoria, depuração e análise de eventos em toda a aplicação.

## Visão Geral

O `logSchema` é projetado para ser uma coleção de "Time Series" (série temporal), onde cada documento representa um evento que ocorreu em um ponto no tempo. Ele é crucial para a observabilidade do sistema.

Uma das características mais importantes deste schema é a **expiração automática de documentos**, implementada para controlar o crescimento da coleção e os custos de armazenamento.

## Dependências

-   `mongoose`: A biblioteca ODM para interagir com o MongoDB.

## Schema Detalhado

### Campos

-   `level` (String, required, enum): O nível de severidade ou a categoria do log. O `enum` restringe os valores a uma lista predefinida, garantindo consistência.
-   `evento` (String, required, index): Um nome curto e único para o tipo de evento (ex: 'ROLL_EXECUTED', 'KARMA_APPLIED', 'SYSTEM_LOG'). É indexado para permitir buscas rápidas por tipo de evento.
-   `mensagem` (String, required): Uma descrição legível do que aconteceu.
-   `detalhes` (Mixed): Um campo flexível (`mongoose.Schema.Types.Mixed`) para armazenar um objeto com quaisquer dados contextuais relevantes para o evento. Permite registrar o `body` de uma requisição, o resultado de uma operação, etc.
-   `guildId` (String, index): O ID da guilda onde o evento ocorreu. Indexado para facilitar a filtragem de logs por guilda.
-   `usuarioId` (String, index): O ID do usuário que iniciou o evento. Indexado para facilitar a busca por atividades de um usuário específico.
-   `data` (Date): A data em que o evento ocorreu.
    -   **`default: Date.now`**: O valor padrão é o momento da criação do documento.
    -   **`expires: '60d'`**: Esta é a configuração chave para o **TTL (Time To Live) Index**. O MongoDB irá automaticamente remover documentos desta coleção 60 dias após a data especificada neste campo. Isso garante que a coleção de logs não cresça indefinidamente.

### Opções do Schema

-   `timestamps: false`: Desativado porque já existe um campo `data` customizado com a funcionalidade de expiração.
-   `versionKey: false`: Desativa o campo `__v`.

### Índices (`logSchema.index(...)`)

Além dos índices definidos diretamente nos campos (`evento`, `guildId`, `usuarioId`), um **índice composto** é criado:
-   `logSchema.index({ level: 1, data: -1 })`: Este índice otimiza consultas que filtram por `level` e ordenam por `data` (do mais novo para o mais antigo), um padrão de busca muito comum para analisar logs recentes de um tipo específico (ex: buscar todos os 'ERROR's da última hora).

## Modelo Exportado

O arquivo exporta o modelo `Log` compilado, pronto para ser usado para registrar eventos em qualquer parte do sistema.

```javascript
module.exports = mongoose.model('Log', logSchema);
```

## Uso no Sistema

O modelo `Log` é amplamente utilizado:
-   No `analyticsController` para persistir logs e eventos recebidos pela API.
-   Nos `services` (`rollService`, `rpedService`) para registrar eventos de negócio importantes de forma "fire-and-forget" (sem bloquear a execução principal) através de uma fila de auditoria (como a implementada em `src/utils/auditQueue.js`).
