# `src/models/Rolagem.js`

Este arquivo define o `Schema` do Mongoose para o modelo `Rolagem`, que serve como um log de auditoria detalhado para cada rolagem de dado individual processada pelo sistema RPED.

## Visão Geral

O principal propósito deste modelo é a **transparência e a capacidade de auditoria**. Ele armazena um "snapshot" completo do estado do sistema no momento de uma rolagem, incluindo o resultado, os modificadores, as médias que influenciaram o cálculo e qual ação de equilíbrio (Karma, Resgate) foi tomada.

Assim como o modelo `Log`, ele utiliza um **índice TTL** para expirar documentos automaticamente, mantendo a coleção gerenciável.

## Dependências

-   `mongoose`: A biblioteca ODM para interagir com o MongoDB.

## Schema Detalhado

### Campos

-   `usuarioId` (String, required, index): O ID do usuário que realizou a rolagem.
-   `guildId` (String, required, index): O ID da guilda onde a rolagem ocorreu.
-   `tipoDado` (Number, required): O número de faces do dado rolado (ex: 20 para um d20).
-   `faceExibida` (Number, required): O valor da face do dado que foi exibido para o usuário. Note que este pode não ser o valor real usado no cálculo, devido à "engenharia reversa" do sistema RPED.
-   `modificador` (Number, required): O modificador (`+` ou `-`) adicionado à rolagem.
-   `totalFinal` (Number, required): O resultado final da rolagem (`faceExibida` + `modificador`).
-   `estatisticas` (Object): Um objeto aninhado que captura o estado do sistema no momento da rolagem.
    -   `mediaIndividual`: A média de rolagens do usuário antes desta rolagem.
    -   `mediaGlobal`: A média de rolagens da guilda antes desta rolagem.
    -   `nivelSorte`: O nível de sorte diária do usuário no momento da rolagem.
    -   `acaoSistema`: Uma string que indica se o sistema interveio na rolagem, podendo ser 'Nenhuma', 'Karma' ou 'Resgate'.
-   `data` (Date): A data da rolagem, com duas configurações importantes:
    -   `default: Date.now`: Garante que a data seja registrada automaticamente.
    -   `expires: '30d'`: Cria um **índice TTL** no MongoDB que remove automaticamente os documentos desta coleção após 30 dias. Este período é menor que o dos logs gerais, pois os detalhes de rolagens são menos críticos a longo prazo.

### Opções do Schema

-   `timestamps: false` e `versionKey: false`: Desativados para manter os documentos mais limpos.

### Índices

-   `rolagemSchema.index({ guildId: 1, usuarioId: 1 })`: Um **índice composto** que otimiza consultas que filtram por guilda e, em seguida, por usuário. Isso é útil para, por exemplo, buscar o histórico de rolagens de um jogador específico em um servidor.

## Modelo Exportado

O arquivo exporta o modelo `Rolagem` compilado.

```javascript
module.exports = mongoose.model('Rolagem', rolagemSchema);
```

## Uso no Sistema

Este modelo é usado principalmente pelo `rollService` e `rpedService`. Após uma rolagem ser completamente processada, um documento `Rolagem` é criado de forma assíncrona (via `auditQueue`) para não impactar a latência da resposta ao usuário. Ele serve como o registro definitivo do que aconteceu em cada intervenção do sistema.
