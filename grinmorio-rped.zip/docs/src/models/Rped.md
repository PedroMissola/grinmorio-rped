# `src/models/Rped.js`

Este arquivo define o `Schema` do Mongoose para o modelo `Rped`, que funciona como um "documento singleton" para armazenar o estado e as estatísticas globais de todo o sistema de equilíbrio de rolagens.

## Visão Geral

Diferente dos outros modelos onde vários documentos podem existir (um para cada guilda, usuário, etc.), a intenção é que exista **apenas um documento** na coleção `rpeds`. Este documento é identificado por um `systemId` fixo ('GRINMORIO_CORE') e age como um repositório central para contadores e estados que afetam a aplicação inteira.

## Dependências

-   `mongoose`: A biblioteca ODM para interagir com o MongoDB.

## Schema Detalhado

### Campos

-   `systemId` (String, required, unique): O identificador único deste documento singleton. O valor padrão é `'GRINMORIO_CORE'`, garantindo que, ao ser criado, ele tenha sempre a mesma identidade. O índice `unique` reforça a regra de que só pode haver um.
-   `grandeObservador` (Object): Um objeto aninhado que armazena estatísticas vitais e de longa duração sobre as intervenções do sistema.
    -   `totalDadosSorteados` (Number): Um contador de quantos dados já foram rolados em toda a história da aplicação.
    -   `totalKarmasAplicados` (Number): Contador de quantas vezes o mecanismo de Karma foi ativado.
    -   `totalResgatesAplicados` (Number): Contador de quantas vezes o Modo Resgate foi ativado.
-   `sorteGlobal` (Object): Um objeto para armazenar modificadores de sorte que podem, eventualmente, afetar todo o sistema (uma mecânica potencialmente futura).
    -   `modificadorAtual` (Number): O valor do modificador de sorte global.
    -   `ultimaMudanca` (Date): A data da última alteração neste modificador.

### Opções do Schema

-   `timestamps: true`: Adiciona `createdAt` e `updatedAt` para rastrear quando o documento de estado global foi criado e modificado.
-   `versionKey: false`: Remove o campo `__v`.

## Modelo Exportado

O arquivo exporta o modelo `Rped` compilado.

```javascript
module.exports = mongoose.model('Rped', rpedSchema);
```

## Uso no Sistema

Este modelo é acessado em pontos estratégicos para ler ou atualizar o estado global:
-   **Leitura:** No `statsController` (`getBotStats`), para buscar os contadores do `grandeObservador` e exibi-los nas estatísticas globais do bot.
-   **Escrita:** No `rpedService`, sempre que uma intervenção de Karma ou Resgate ocorre, o respectivo contador no documento `GRINMORIO_CORE` é incrementado usando uma operação atômica do MongoDB (como `$inc`), garantindo que a contagem seja segura mesmo com múltiplas requisições concorrentes.
