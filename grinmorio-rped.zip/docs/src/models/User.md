# `src/models/User.js`

Este arquivo define o `Schema` do Mongoose para o modelo `User`, que representa um usuário do Discord de forma global, independente das guildas em que ele está.

## Visão Geral

O `userSchema` armazena informações que pertencem ao usuário em toda a aplicação, como seu ID, permissões de acesso ao bot e estatísticas globais que não são específicas de uma única guilda.

## Dependências

-   `mongoose`: A biblioteca ODM para interagir com o MongoDB.

## Schemas Definidos

### `punicaoSchema`

-   **Descrição:** Um subdocumento para registrar punições aplicadas a um usuário. Assim como o `guildMemberSchema` em `Guild.js`, ele é parte do `userSchema` e não um modelo independente.
-   **Campos:**
    -   `tipo` (String, required, enum): O tipo de punição, restrito a 'ban' ou 'warn'.
    -   `motivo` (String): A razão pela qual a punição foi aplicada.
    -   `data` (Date): A data em que a punição foi registrada.
    -   `expiraEm` (Date): Uma data futura para a expiração da punição (útil para bans temporários).
-   **Opções:**
    -   `_id: false`: Impede a criação de um `_id` para cada registro de punição.

### `userSchema`

-   **Descrição:** O schema principal para o modelo `User`.
-   **Campos Principais:**
    -   `userId` (String, required, unique, index): O ID do usuário do Discord, servindo como a chave primária única para cada documento de usuário.
    -   `comandosUsados` (Number): Um contador global de quantos comandos o usuário já utilizou.
    -   `mediaSorteGlobal` (Number): A média de sorte do usuário, considerando todas as rolagens em todas as guildas. Este campo pode ser usado para análises de longo prazo do comportamento do jogador.
    -   `punicoes` (Array de `punicaoSchema`): Um histórico de todas as punições aplicadas ao usuário.
    -   `permissaoBot` (String, enum): O nível de permissão do usuário dentro do ecossistema do bot. Os níveis são 'jogador', 'suporte', e 'desenvolvedor', permitindo um controle de acesso refinado para comandos administrativos ou de depuração.
-   **Opções do Schema:**
    -   `timestamps: true`: Adiciona os campos `createdAt` e `updatedAt`.
    -   `versionKey: false`: Remove o campo `__v`.

## Modelo Exportado

O arquivo exporta o modelo `User` compilado, pronto para uso.

```javascript
module.exports = mongoose.model('User', userSchema);
```

## Uso no Sistema

O modelo `User` é utilizado em vários contextos:
-   **Criação/Atualização:** Um usuário é geralmente criado ou atualizado (`findOneAndUpdate` com `upsert: true`) na primeira vez que ele interage com o bot, garantindo que um perfil exista para ele.
-   **Estatísticas:** O `statsController` usa este modelo para buscar informações para a "ficha do jogador" global.
-   **Permissões:** Comandos administrativos ou de depuração podem verificar o campo `permissaoBot` para autorizar ou negar a execução.
-   **Moderação:** Futuramente, um sistema de moderação pode usar o array `punicoes` para gerenciar o comportamento dos usuários.
