# `src/routes/analyticsRoutes.js`

Este arquivo define as rotas da API relacionadas a analytics e logging, conectando os endpoints HTTP aos seus respectivos `controllers` e aplicando os middlewares necessários.

## Visão Geral

O roteador aqui exposto lida com o recebimento de dados de eventos e logs do sistema, garantindo que eles sejam validados e que o tráfego seja controlado antes de chegarem à lógica de negócio.

## Dependências

-   `express`: O framework web para criar o roteador.
-   `../controllers/analyticsController`: Contém a lógica de negócio para processar os eventos e logs.
-   `../middlewares/validate`: O middleware de validação genérico baseado em Zod.
-   `../schemas/analyticsSchema`: Contém os schemas Zod (`recordEventSchema`, `saveLogSchema`) para validar o corpo das requisições.
-   `../middlewares/rateLimiters`: Fornece o `analyticsLimiter` para controlar a taxa de requisições.

## Rotas Definidas

### `POST /stats/record`

-   **Descrição:** Rota para registrar um evento de analytics genérico.
-   **Cadeia de Middlewares:**
    1.  `analyticsLimiter`: Primeiro, o middleware de limitação de taxa é aplicado. Se o cliente exceder o limite de requisições para endpoints de analytics (ex: 50 requisições por minuto), a requisição é bloqueada com um erro `429 Too Many Requests`.
    2.  `validate(recordEventSchema)`: Em seguida, o corpo da requisição é validado contra o `recordEventSchema`. Se o formato dos dados estiver incorreto (ex: `event` não é uma string), a requisição é bloqueada com um erro `400 Bad Request`.
    3.  `analyticsController.recordEvent`: Se a requisição passar pelos dois middlewares anteriores, ela finalmente chega ao `controller`, que processa e salva o evento.

### `POST /logs`

-   **Descrição:** Rota para salvar uma entrada de log mais genérica do sistema.
-   **Cadeia de Middlewares:**
    1.  `analyticsLimiter`: O mesmo limitador de taxa é aplicado.
    2.  `validate(saveLogSchema)`: O corpo da requisição é validado contra o `saveLogSchema`, que define as regras para os campos `level`, `message`, e `details`.
    3.  `analyticsController.saveLog`: O `controller` correspondente é executado para persistir o log.

## Boas Práticas

-   **Separação de Responsabilidades:** O arquivo de rotas se concentra exclusivamente em definir os endpoints e sua cadeia de middlewares, sem conter nenhuma lógica de negócio.
-   **Segurança e Validação na Entrada:** A aplicação de middlewares de `rateLimit` e `validate` diretamente na camada de roteamento é uma prática de segurança fundamental, pois bloqueia requisições malformadas ou abusivas o mais cedo possível, antes que consumam recursos do servidor.
