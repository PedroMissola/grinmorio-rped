# `src/routes/guildRoutes.js`

Este arquivo define as rotas da API para gerenciamento de configurações de guildas (servidores do Discord).

## Visão Geral

O roteador expõe endpoints para ler e atualizar as configurações de uma guilda específica, aplicando uma cadeia de middlewares para garantir segurança, validação e controle de tráfego.

## Dependências

-   `express`: Framework para criação do roteador.
-   `../controllers/guildController`: Contém a lógica para interagir com o modelo `Guild`.
-   `../middlewares/validate`: Middleware de validação com Zod.
-   `../middlewares/sanitize`: Fornece o `sanitizeParams` para proteger contra NoSQL Injection nos parâmetros da URL.
-   `../schemas/guildSchema`: Contém o `updateGuildSettingsSchema` para validar o corpo da requisição de atualização.
-   `../middlewares/rateLimiters`: Fornece o `guildSettingsLimiter` para controlar a taxa de requisições.

## Rotas Definidas

### `GET /:guildId/settings`

-   **Descrição:** Rota para buscar as configurações de uma guilda específica.
-   **Parâmetros de Rota:**
    -   `:guildId`: O ID da guilda do Discord.
-   **Cadeia de Middlewares:**
    1.  `sanitizeParams`: Valida o parâmetro `:guildId` na URL, rejeitando a requisição se ele contiver caracteres perigosos (como `$`, `{`, `}`), prevenindo ataques de NoSQL Injection.
    2.  `guildController.getGuildSettings`: Se o parâmetro for limpo, a requisição chega ao `controller`, que busca e retorna as configurações.
-   **Nota:** Esta rota não possui `rate limiter` nem `validate` porque é uma operação de leitura (`GET`) que não recebe corpo e é considerada menos "cara" ou sensível que uma operação de escrita.

### `PUT /:guildId/settings`

-   **Descrição:** Rota para atualizar as configurações de uma guilda.
-   **Parâmetros de Rota:**
    -   `:guildId`: O ID da guilda a ser atualizada.
-   **Cadeia de Middlewares (executados em ordem):**
    1.  `guildSettingsLimiter`: Aplica uma limitação de taxa específica para esta operação, prevenindo updates excessivos em um curto período.
    2.  `sanitizeParams`: Sanitiza o parâmetro `:guildId` da URL, assim como na rota `GET`.
    3.  `validate(updateGuildSettingsSchema)`: Valida o corpo (`body`) da requisição. Se o corpo não contiver um objeto `settings` com os campos esperados (ex: `prefix`, `rollChannels`), a requisição é rejeitada com um erro `400 Bad Request`.
    4.  `guildController.updateGuildSettings`: Apenas se todos os middlewares anteriores passarem, o `controller` é executado para realizar a atualização no banco de dados.

## Padrão de Design

A composição da cadeia de middlewares para a rota `PUT` é um excelente exemplo de "defesa em profundidade" aplicada no nível do roteamento:
1.  **Controle de Abuso** (`guildSettingsLimiter`)
2.  **Segurança de Input na URL** (`sanitizeParams`)
3.  **Validação de Formato do Body** (`validate`)
4.  **Execução da Lógica de Negócio** (`guildController`)

Cada etapa foca em um aspecto diferente da segurança e integridade da requisição.
