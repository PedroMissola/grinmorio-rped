# `src/routes/rollRoutes.js`

Este arquivo define a rota para a funcionalidade mais central e crítica da aplicação: o processamento de rolagens de dados.

## Visão Geral

O roteador expõe um único endpoint (`POST /roll`) que serve como o ponto de entrada para todas as requisições de rolagem. Ele aplica uma cadeia de middlewares para garantir que apenas requisições válidas e de fontes controladas cheguem ao `controller`.

## Dependências

-   `express`: Framework para criação do roteador.
-   `../controllers/rollController`: Contém a lógica de alto nível que delega a execução da rolagem para o `rollService`.
-   `../middlewares/validate`: O middleware de validação genérico.
-   `../schemas/rollSchema`: O schema Zod que define o formato exato esperado para os dados de uma rolagem no corpo da requisição.
-   `../middlewares/rateLimiters`: Fornece o `rollLimiter`, um limitador de taxa restrito e específico para esta rota.

## Rota Definida

### `POST /roll`

-   **Descrição:** O endpoint principal para executar uma rolagem de dado através do sistema RPED.
-   **Cadeia de Middlewares:**
    1.  `rollLimiter`: O primeiro middleware na cadeia. Ele aplica a política de limitação de taxa mais restrita da API (ex: 10 requisições por 10 segundos). Isso é crucial para proteger os `services` (que são intensivos em CPU e I/O com o Redis) de serem sobrecarregados por um cliente mal-intencionado ou com bugs.
    2.  `validate(rollSchema)`: O segundo passo. Valida o corpo da requisição contra o `rollSchema`. Isso garante que campos como `guildId`, `usuarioId`, e `tamanhoDado` existam, estejam no formato correto e dentro dos limites esperados (ex: `tamanhoDado` deve ser um número inteiro). Requisições malformadas são rejeitadas aqui.
    3.  `rollController.postRoll`: Apenas se a requisição passar pelas duas barreiras anteriores, o controle é passado para o `controller`, que então orquestra a execução da lógica de negócio.

## Importância da Ordem dos Middlewares

A ordem dos middlewares nesta rota é intencional e otimizada para performance e segurança:
-   O `rateLimiter` vem primeiro porque é a verificação mais "barata". Ele consulta um contador em memória (ou no Redis, dependendo da configuração) e pode rejeitar uma requisição sem precisar analisar seu conteúdo. Colocá-lo no início protege os middlewares mais "caros" (como a validação de schema) de serem executados desnecessariamente em um ataque de negação de serviço.
-   A validação (`validate`) vem em segundo, garantindo que o `controller` nunca precise se preocupar com dados ausentes ou em formato incorreto, simplificando enormemente a lógica de negócio.
