# `src/routes/statsRoutes.js`

Este arquivo define as rotas da API para a consulta de estatísticas, sejam elas globais, por guilda ou por usuário.

## Visão Geral

O roteador expõe um conjunto de endpoints de leitura (`GET`) que permitem a clientes obterem dados estatísticos compilados do sistema. Diferente de outras rotas de `POST` ou `PUT`, estas não possuem middlewares de validação de corpo ou de limitação de taxa, pois são operações de leitura consideradas menos críticas.

## Dependências

-   `express`: Framework para criação do roteador.
-   `../controllers/statsController`: Contém a lógica de negócio para buscar, compilar e formatar os dados estatísticos.

## Rotas Definidas

### `GET /bot`

-   **Descrição:** Retorna um objeto com as estatísticas globais do bot/sistema.
-   **Cadeia de Middlewares:**
    1.  `statsController.getBotStats`: A requisição é enviada diretamente para o `controller` correspondente, que consulta vários modelos (`User`, `Guild`, `Rped`) para montar a resposta.

### `GET /guild/:guildId`

-   **Descrição:** Retorna as estatísticas agregadas de uma guilda específica.
-   **Parâmetros de Rota:**
    -   `:guildId`: O ID da guilda do Discord cujas estatísticas são desejadas.
-   **Cadeia de Middlewares:**
    1.  `statsController.getGuildStats`: A requisição vai direto para o `controller`, que usa o `:guildId` para encontrar o documento da guilda e compilar os dados de seus membros.
-   **Nota:** Embora não haja um `sanitizeParams` explícito aqui, a forma como o Mongoose usa o `guildId` para buscar (`findOne({ guildId: ... })`) já previne vulnerabilidades de NoSQL Injection para este caso de uso simples. Uma sanitização explícita poderia ser adicionada por consistência, seguindo o padrão de `guildRoutes.js`.

### `GET /user/:userId`

-   **Descrição:** Retorna a "ficha" de um jogador, com suas estatísticas e histórico recente de rolagens.
-   **Parâmetros de Rota:**
    -   `:userId`: O ID do usuário do Discord.
-   **Cadeia de Middlewares:**
    1.  `statsController.getUserStats`: O `controller` busca os dados do usuário nos modelos `User` e `Rolagem` e os retorna.

## Considerações de Design

-   **Simplicidade:** As rotas são diretas e mapeiam claramente para as funções do `controller`.
-   **Segurança:** A ausência de middlewares de escrita (como `validate` ou `rate-limit`) é apropriada para endpoints `GET` que não alteram o estado do sistema. Um rate limiter global, se existente, ainda se aplicaria, oferecendo uma camada base de proteção contra DoS.
