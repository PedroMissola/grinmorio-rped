# `src/schemas/analyticsSchema.js`

Este arquivo define os schemas de validação da biblioteca **Zod** para os endpoints de analytics e logging.

## Visão Geral

O objetivo deste arquivo é garantir que os dados enviados para as rotas de analytics (`/stats/record` e `/logs`) sejam bem-formados, contenham os campos necessários e estejam dentro dos tipos e formatos esperados. Isso previne a entrada de dados "lixo" no sistema e fornece mensagens de erro claras para os clientes da API.

## Dependências

-   `zod`: A biblioteca de declaração e validação de schemas.

## Constantes

### `VALID_LEVELS`

-   **Descrição:** Um array de strings que define todos os valores permitidos para o campo `level` em um log.
-   **Uso:** É usado no `saveLogSchema` para criar uma validação de `enum`.

## Schemas Exportados

### `recordEventSchema`

-   **Rota Alvo:** `POST /stats/record`
-   **Descrição:** Valida o corpo da requisição para o registro de um evento de analytics.
-   **Regras de Validação:**
    -   `event` (String):
        -   É um campo **obrigatório**. Uma mensagem de erro customizada é definida para o caso de ausência.
        -   Deve ter no mínimo 1 caractere e no máximo 100.
    -   `details` (Objeto):
        -   É um campo **opcional**.
        -   Se não for fornecido, o valor padrão será um objeto vazio (`{}`).
        -   É definido como `z.record(z.unknown())`, o que significa que ele aceita um objeto com qualquer chave (string) e qualquer valor (`unknown`), oferecendo máxima flexibilidade para os detalhes do evento.

### `saveLogSchema`

-   **Rota Alvo:** `POST /logs`
-   **Descrição:** Valida o corpo da requisição para o salvamento de um log de sistema.
-   **Regras de Validação:**
    -   `level` (String, Enum):
        -   O valor deve ser um dos presentes no array `VALID_LEVELS`. Uma mensagem de erro personalizada é mostrada se um valor inválido for enviado.
        -   Se não for fornecido, o valor padrão será `'INFO'`.
    -   `message` (String):
        -   É um campo **opcional**.
        -   Se fornecido, deve ter no mínimo 1 e no máximo 500 caracteres.
    -   `details` (Objeto):
        -   É **opcional** e seu valor padrão é um objeto vazio, assim como no `recordEventSchema`.

## Uso no Sistema

Estes schemas são importados no arquivo de rotas `src/routes/analyticsRoutes.js` e passados para o middleware `validate`.

```javascript
// Exemplo em analyticsRoutes.js
const { validate } = require('../middlewares/validate');
const { recordEventSchema } = require('../schemas/analyticsSchema');

router.post('/stats/record', validate(recordEventSchema), analyticsController.recordEvent);
```

Isso garante que, antes do `analyticsController` ser executado, o corpo da requisição já foi rigorosamente validado e, em caso de sucesso, os valores padrão e coerções de tipo (se houver) já foram aplicados.
