# `src/schemas/guildSchema.js`

Este arquivo define o schema de validação Zod para o corpo da requisição de atualização das configurações de uma guilda.

## Visão Geral

Seu objetivo é validar os dados enviados para o endpoint `PUT /:guildId/settings`, garantindo que todas as configurações fornecidas sejam válidas e estejam no formato correto antes de serem persistidas no banco de dados.

## Dependências

-   `zod`: A biblioteca de declaração e validação de schemas.

## Schemas Exportados

### `updateGuildSettingsSchema`

-   **Rota Alvo:** `PUT /:guildId/settings`
-   **Descrição:** Valida um objeto `settings` aninhado dentro do corpo da requisição.
-   **Regras de Validação:**
    -   O schema espera um objeto principal com uma única chave: `settings`.
    -   O objeto `settings` é validado com a opção `.strict()`, o que significa que qualquer campo enviado dentro de `settings` que **não** esteja explicitamente definido no schema (como `prefix`, `rollChannels`, etc.) causará um erro de validação. Isso previne que o cliente envie campos arbitrários ou com erros de digitação.

#### Campos Dentro de `settings`

Todos os campos dentro de `settings` são **opcionais** (`.optional()`), permitindo que o cliente envie apenas as configurações que deseja alterar (uma atualização parcial ou `PATCH`-like).

-   `prefix` (String):
    -   Se fornecido, deve ser uma string com no mínimo 1 e no máximo 3 caracteres.
-   `rollChannels` (Array de Strings):
    -   Se fornecido, deve ser um array.
    -   O array pode ter no máximo 50 elementos.
    -   Cada elemento do array deve ser uma string com no mínimo 1 e no máximo 30 caracteres.
-   `logChannelId` (String ou Null):
    -   Se fornecido, pode ser uma string, `null`, ou `undefined`.
    -   Se for uma string, deve ter no máximo 30 caracteres e conter apenas dígitos (`.regex(/^\d+$/)`), validando o formato de um ID do Discord.
    -   O `.nullable()` permite que o cliente envie explicitamente `null` para desativar o canal de log.
-   `statsChannelId` (String ou Null):
    -   Possui as mesmas regras de validação do `logChannelId`.

## Uso no Sistema

Este schema é importado no arquivo `src/routes/guildRoutes.js` e usado com o middleware `validate` para proteger a rota de atualização de configurações.

```javascript
// Exemplo em guildRoutes.js
router.put(
    '/:guildId/settings',
    validate(updateGuildSettingsSchema), // Middleware de validação
    guildController.updateGuildSettings
);
```
