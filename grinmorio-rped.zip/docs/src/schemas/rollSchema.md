# `src/schemas/rollSchema.js`

Este arquivo define o schema de validação Zod para o corpo da requisição da rota de rolagem (`POST /roll`), a mais importante da API.

## Visão Geral

O `rollSchema` garante que todos os dados necessários para processar uma rolagem sejam fornecidos, estejam nos formatos corretos e dentro de limites razoáveis, antes de qualquer lógica de negócio ser executada. Ele também aplica coerção de tipo, transformando inputs em tipos de dados consistentes.

## Dependências

-   `zod`: A biblioteca de declaração e validação de schemas.

## Schema Exportado

### `rollSchema`

-   **Rota Alvo:** `POST /roll`
-   **Descrição:** Valida o corpo da requisição para uma nova rolagem. Todos os campos são, por padrão, obrigatórios, a menos que `.optional()` ou `.default()` seja usado.
-   **Regras de Validação:**
    -   `guildId` (String):
        -   É um campo **obrigatório**.
        -   Deve ser uma string com no mínimo 1 e no máximo 30 caracteres.
        -   Deve conter apenas dígitos (`.regex(/^\d+$/)`), validando o formato de um ID do Discord.
    -   `usuarioId` (String):
        -   Possui as mesmas regras de validação do `guildId`.
    -   `tamanhoDado` (Number):
        -   Zod tentará coagir o valor para um número, se possível.
        -   Deve ser um número **inteiro**.
        -   O valor mínimo é `4` (representando um d4).
        -   O valor máximo é `1000` (representando um d1000).
        -   Se não for fornecido, seu valor padrão será `20`.
    -   `modificador` (Number):
        -   Deve ser um número **inteiro**.
        -   O valor deve estar entre `-100` e `100`.
        -   Se não for fornecido, seu valor padrão será `0`.

## Pontos de Destaque

-   **Coerção de Tipo:** O uso de `z.number()` é poderoso. Se o cliente enviar `tamanhoDado: "20"` (uma string) no JSON, o Zod automaticamente o converterá para o número `20` antes de passar os dados para o `controller`, desde que a conversão seja válida. Isso torna a API mais robusta a pequenas inconsistências de tipo no input.
-   **Valores Padrão:** O uso de `.default()` para `tamanhoDado` e `modificador` simplifica a vida do cliente da API. Ele pode fazer uma requisição de rolagem simples enviando apenas `guildId` e `usuarioId`, e o sistema assumirá que se trata de uma rolagem de 1d20+0.
-   **Validação de Formato:** O uso de `.regex(/^\d+$/)` para os IDs garante que apenas strings numéricas, como as usadas pelo Discord, sejam aceitas, rejeitando qualquer outro formato.

## Uso no Sistema

Este schema é importado em `src/routes/rollRoutes.js` e aplicado na rota `POST /roll` através do middleware `validate`.

```javascript
// Exemplo em rollRoutes.js
router.post('/roll', validate(rollSchema), rollController.postRoll);
```
