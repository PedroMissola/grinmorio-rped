# `src/services/rollService.js`

Este arquivo é um dos mais importantes da aplicação, contendo a implementação central da lógica de negócio do sistema RPED (Rolagem Ponderada com Engenharia Dinâmica).

**Nota:** O nome `rollService` pode ser um pouco enganoso. Na versão atual, ele parece ser o orquestrador principal, enquanto o `rpedService` atua mais como um conjunto de utilitários de persistência e leitura de dados. Uma futura refatoração poderia clarificar esses papéis.

## Visão Geral

Este serviço é responsável por executar uma rolagem de dado do início ao fim, aplicando todas as camadas do algoritmo de equilíbrio:
1.  Obtém a sorte diária do jogador.
2.  Obtém as médias de rolagem (individual e da guilda).
3.  Executa uma rolagem de dado "ponderada" com base na sorte.
4.  Aplica as lógicas de **Karma** ou **Resgate**.
5.  Garante que o resultado final esteja dentro dos limites do dado.
6.  Persiste o resultado no Redis e dispara o log de auditoria para o MongoDB.
7.  Retorna o resultado final para o `controller`.

## Dependências

-   `../config/redis`: Para obter o cliente Redis.
-   `../config/rpedConstants`: Para acessar todas as constantes de negócio (limiares, taxas, etc.).
-   `../utils/mathUtils`: Para funções matemáticas como `rollWeightedDice` e `clamp`.
-   `./rpedService`: Para funções auxiliares de acesso a dados (obter médias, registrar rolagens).

## Funções Auxiliares (Não Exportadas)

### `getDailyLuck(userId)`

-   **Método:** `async`
-   **Descrição:** Obtém a "sorte do dia" de um usuário, um valor entre 0 e 10.
-   **Lógica:**
    1.  Tenta buscar o valor do Redis (`rped:user:{userId}:luck`).
    2.  Se o valor **não estiver em cache** (primeira rolagem do dia do usuário):
        -   Gera um novo número de sorte. A lógica `(Math.random() + ...)` é uma forma simples de aproximar uma **distribuição normal (curva de sino)**, fazendo com que valores intermediários (como 4, 5, 6) sejam mais comuns que valores extremos (0 ou 10).
        -   Salva o valor no Redis com um TTL (Time To Live) de 24 horas.
    3.  Retorna o valor da sorte.

### `updateRescueHysteresis(guildId, globalAverage)`

-   **Método:** `async`
-   **Descrição:** Gerencia o estado do "Modo Resgate" para uma guilda, usando um mecanismo de **histerese**.
-   **Lógica:**
    1.  Busca o estado atual do Modo Resgate no Redis.
    2.  **Ativação:** Se a média global da guilda (`globalAverage`) cair abaixo do `RESCUE_ACTIVATION_THRESHOLD` e o modo não estiver ativo, ele o ativa (seta a chave no Redis para `'true'`).
    3.  **Desativação:** Se a média global subir acima do `RESCUE_DEACTIVATION_THRESHOLD` (um limiar *diferente* e mais alto) e o modo estiver ativo, ele o desativa.
-   **Importância da Histerese:** Usar dois limiares diferentes evita que o sistema fique "piscando" (ligando e desligando o Modo Resgate rapidamente) se a média ficar oscilando em torno de um único valor.

## Função Principal Exportada

### `executeRoll(guildId, userId, diceSize, modifier)`

-   **Método:** `async`
-   **Descrição:** O pipeline completo de execução de uma rolagem.
-   **Pipeline de Execução:**
    1.  **Coleta de Dados:** Chama `getDailyLuck` e `rpedService.getAverages` para obter os três principais inputs do algoritmo: sorte, média individual e média da guilda.
    2.  **Rolagem Ponderada:** Chama `mathUtils.rollWeightedDice` para obter um resultado inicial influenciado pela sorte do jogador.
    3.  **Histerese:** Atualiza e obtém o estado atual do Modo Resgate.
    4.  **Aplicação de Lógica de Equilíbrio:**
        -   **Karma:** Verifica se as condições para o Karma são atendidas (jogador com média muito alta rolando um valor alto). Se sim, aplica uma penalidade (`KARMA_PENALTY_RATE`) ao resultado.
        -   **Resgate:** Se o Karma não foi aplicado e o Modo Resgate está ativo, calcula e adiciona um bônus à rolagem.
    5.  **Clamping:** Usa `mathUtils.clamp` para garantir que o resultado final (`displayFace`), após todas as modificações, nunca seja menor que 1 ou maior que o tamanho do dado (`diceSize`).
    6.  **Cálculo Final:** Soma o `modifier` do personagem ao `displayFace` para obter o `finalTotal`.
    7.  **Persistência:**
        -   Chama `rpedService.recordRollRedis` para atualizar os históricos no Redis (operação rápida e síncrona no fluxo).
        -   Chama `rpedService.saveRollLog` para enfileirar a escrita do log de auditoria completo no MongoDB (operação mais lenta, feita de forma "fire-and-forget").
    8.  **Retorno:** Retorna um objeto contendo o resultado final e um resumo das estatísticas que influenciaram a rolagem, pronto para ser enviado ao cliente pelo `controller`.
