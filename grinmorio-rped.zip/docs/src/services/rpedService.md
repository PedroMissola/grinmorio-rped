# `src/services/rpedService.js`

Este arquivo funciona como um conjunto de funções de serviço focadas na **interação com as fontes de dados** (Redis e MongoDB) para a lógica RPED.

**Nota:** Conforme observado na documentação do `rollService.js`, os papéis entre os dois serviços poderiam ser mais claros. Atualmente, `rpedService` atua como um "serviço de dados" para o `rollService`, que é o orquestrador principal.

## Visão Geral

As responsabilidades deste serviço são:
1.  Gravar os resultados de rolagens no histórico do Redis.
2.  Calcular as médias de rolagem (individual e da guilda) a partir do histórico do Redis.
3.  Persistir o log de auditoria detalhado de uma rolagem no MongoDB de forma assíncrona e resiliente.

## Dependências

-   `../config/redis`: Para obter o cliente Redis.
-   `../models/Rolagem`: O modelo Mongoose para os logs de auditoria de rolagens.
-   `../utils/auditQueue`: A fila para processamento assíncrono e com retentativas de tarefas de auditoria.
-   `../config/rpedConstants`: Para obter as constantes de configuração de histórico (`HISTORY_*`).

## Funções Exportadas

### `recordRollRedis(guildId, userId, displayFace, diceSize)`

-   **Método:** `async`
-   **Descrição:** Registra o resultado de uma nova rolagem nos históricos do Redis.
-   **Lógica:**
    1.  **Normalização:** O valor da face rolada (`displayFace`) é **normalizado** para uma escala de 0 a 1, dividindo-o pelo tamanho do dado (`diceSize`). Isso é **crucial** para que o sistema possa comparar a "qualidade" de uma rolagem de um d20 com a de um d6, por exemplo.
    2.  **Chaves do Redis:** Define as chaves para as listas de histórico do usuário e da guilda. A estrutura `rped:guild:{id}:...` organiza os dados de forma hierárquica.
    3.  **Pipeline:** Usa `redis.pipeline()` para agrupar múltiplos comandos em uma única operação de rede, o que é significativamente mais performático do que enviar cada comando individualmente.
        -   `lpush`: Adiciona o valor normalizado no início da lista (LIFO - Last-In, First-Out).
        -   `ltrim`: Remove elementos antigos da lista, mantendo-a com um tamanho fixo (`HISTORY_USER_SIZE` ou `HISTORY_GUILD_SIZE`). Isso cria uma **janela deslizante** de histórico.
    4.  Executa o pipeline. Um `.catch` é usado para logar erros sem travar a aplicação, pois esta operação não é crítica para a resposta ao usuário.

### `getAverages(guildId, userId)`

-   **Método:** `async`
-   **Descrição:** Busca os históricos de rolagem no Redis e calcula as médias normalizadas.
-   **Lógica:**
    1.  Usa `Promise.all` para buscar o histórico do usuário e da guilda em paralelo, otimizando o tempo de resposta.
    2.  Usa uma função auxiliar `calculateAverage` que:
        -   Se o array de histórico tiver elementos, calcula a média aritmética simples.
        -   Se o array estiver vazio (nenhuma rolagem anterior), retorna o `HISTORY_DEFAULT_AVERAGE` (0.5), que representa uma média neutra.
    3.  Retorna um objeto com `individualAverage` e `globalAverage`.

### `saveRollLog(rollData)`

-   **Método:** Síncrono (mas inicia operações assíncronas).
-   **Descrição:** Salva o log de auditoria de uma rolagem no MongoDB de forma **assíncrona e resiliente**.
-   **Lógica:**
    1.  **Mapeamento:** Transforma o objeto `rollData` (que usa nomes em inglês, como `diceSize`) para um documento que corresponde ao schema do Mongoose `Rolagem` (que usa nomes em português, como `tipoDado`), garantindo a compatibilidade.
    2.  **Persistência "Fire-and-Forget":**
        -   Define uma função `persist` que simplesmente chama `Rolagem.create()`.
        -   Tenta executar `persist()` imediatamente.
        -   Se a operação falhar (ex: o MongoDB está temporariamente indisponível), o erro é capturado e, em vez de travar a aplicação, a operação é **enfileirada** usando `enqueue(persist, document)`.
    -   **Importância:** Este padrão garante que a escrita no MongoDB não atrase a resposta da API ao usuário (baixa latência) e que, mesmo em caso de falha, o log de auditoria não seja perdido, mas sim processado mais tarde pela `auditQueue`.
