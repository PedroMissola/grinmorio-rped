# `src/utils/AppError.js`

Este arquivo define a classe `AppError`, um utilitário fundamental para o tratamento de erros em toda a aplicação.

## Visão Geral

O `AppError` é uma classe de erro customizada que estende a classe `Error` nativa do JavaScript. Seu propósito é criar uma distinção clara entre dois tipos de erros:

1.  **Erros Operacionais:** São erros "esperados" que fazem parte do fluxo normal da aplicação. Eles não representam um bug, mas sim uma condição de falha prevista. Exemplos:
    -   Um usuário tenta acessar um recurso que não existe (`404 Not Found`).
    -   Um usuário envia dados inválidos em uma requisição (`400 Bad Request`).
    -   Um usuário tenta executar uma ação para a qual não tem permissão (`403 Forbidden`).
    Estes erros são marcados com a propriedade `isOperational = true`.

2.  **Erros de Programação (Bugs):** São erros inesperados que indicam uma falha no código ou na infraestrutura. Exemplos:
    -   Uma variável `null` é acessada, causando um `TypeError`.
    -   Uma falha de conexão com o banco de dados que não foi tratada.
    -   Um erro de lógica em um algoritmo.
    Para estes casos, o `Error` nativo do JavaScript deve ser usado, ou um `AppError` nunca deve ter `isOperational` setado para `true`.

Essa distinção é crucial para o `errorHandler` global, que pode então decidir como logar o erro e qual mensagem retornar ao cliente.

## Estrutura da Classe

```javascript
class AppError extends Error {
    constructor(message, statusCode = 500) {
        super(message); // Chama o construtor da classe Error com a mensagem
        this.statusCode = statusCode;
        this.isOperational = true;

        Error.captureStackTrace(this, this.constructor);
    }
}
```

-   `extends Error`: `AppError` herda todas as propriedades de um erro padrão, como `message` e `stack`.
-   `constructor(message, statusCode)`:
    -   `message`: A mensagem de erro que é segura para ser exibida ao cliente.
    -   `statusCode`: O código de status HTTP que deve ser usado na resposta (ex: 400, 404, etc.). O padrão é `500` se não for especificado.
-   `this.isOperational = true;`: A "flag" que identifica este erro como um erro operacional.
-   `Error.captureStackTrace(this, this.constructor);`: Uma otimização que remove o construtor do `AppError` do stack trace do erro, tornando o stack mais limpo e apontando diretamente para o local onde o erro foi *criado* (`new AppError(...)`), o que facilita a depuração.

## Uso no Sistema

A classe `AppError` é usada em `controllers` e `services` para sinalizar uma falha operacional de forma explícita.

**Exemplo de Uso (em um controller):**
```javascript
async function getGuildSettings(req, res, next) {
    try {
        const { guildId } = req.params;
        const guild = await Guild.findOne({ guildId });

        // Se a guilda não for encontrada, é um erro operacional, não um bug.
        if (!guild) {
            // Lança o erro para ser capturado pelo errorHandler global.
            throw new AppError('Servidor não encontrado', 404);
        }

        res.status(200).json(guild.configs);
    } catch (error) {
        // Passa o erro (seja AppError ou um bug) para o errorHandler.
        next(error);
    }
}
```
