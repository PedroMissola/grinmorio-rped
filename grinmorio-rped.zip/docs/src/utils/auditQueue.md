# `src/utils/auditQueue.js`

Este arquivo implementa uma fila de auditoria em memória, com lógica de retentativa (`retry`) automática. É um componente crucial para a **resiliência** do sistema de logging.

## Visão Geral

O principal objetivo desta fila é garantir que logs de auditoria importantes (como os detalhes de uma rolagem) não sejam perdidos se o banco de dados (MongoDB) estiver temporariamente indisponível.

Em vez de a operação de escrita no banco de dados bloquear a resposta da API (o que aumentaria a latência) ou falhar silenciosamente, ela é encapsulada. Se a escrita falhar, a tarefa é adicionada a esta fila para ser reprocessada mais tarde.

## Limitações Conhecidas

O próprio código-fonte documenta uma limitação importante:
-   **A fila é volátil:** Por ser um simples array em memória, se o processo da aplicação for reiniciado, todos os itens que estavam na fila serão perdidos.
-   Para uma durabilidade completa, a solução ideal seria usar uma fila persistente, como **BullMQ** com **Redis**, que é uma melhoria comum em sistemas de produção. Para o escopo atual, a fila em memória é uma solução pragmática e eficaz contra falhas *temporárias*.

## Constantes de Configuração

-   `MAX_QUEUE_SIZE`: O número máximo de itens que a fila pode conter. Se a fila estiver cheia, o item mais antigo é descartado para evitar um vazamento de memória (`memory leak`).
-   `RETRY_INTERVAL_MS`: O intervalo de tempo (em milissegundos) entre as tentativas de reprocessar a fila.
-   `MAX_RETRIES_PER_ITEM`: O número máximo de vezes que o sistema tentará reprocessar um único item antes de descartá-lo.

## Lógica de Funcionamento

### `enqueue(persistFn, data)`

-   **Descrição:** A função usada para adicionar um novo trabalho à fila.
-   **Parâmetros:**
    -   `persistFn`: A função assíncrona que executa a tarefa (ex: `async (data) => await Model.create(data)`).
    -   `data`: Os dados que serão passados para a `persistFn`.
-   **Lógica:**
    1.  Verifica se a fila está cheia e descarta o item mais antigo se necessário.
    2.  Adiciona o novo item à fila, incluindo um contador de `retries` inicializado em 0.
    3.  Incrementa um contador global de falhas para monitoramento.
    4.  Se o timer de retentativa não estiver ativo, ele o inicia chamando `scheduleRetry()`.

### `scheduleRetry()`

-   **Descrição:** Agenda a execução da função `processQueue` para o futuro.
-   **Lógica:** Usa `setTimeout` para chamar `processQueue` após `RETRY_INTERVAL_MS` (30 segundos). Isso evita que a fila seja reprocessada em um loop apertado.

### `processQueue()`

-   **Método:** `async`
-   **Descrição:** A função principal que tenta reprocessar os itens da fila.
-   **Lógica:**
    1.  Se a fila estiver vazia, não faz nada.
    2.  Cria uma cópia dos itens atuais (`batch`) e limpa a fila principal. Itens que falharem novamente serão reinseridos.
    3.  Itera sobre cada `item` no `batch`:
        -   Tenta executar a função `persistFn` do item.
        -   **Em caso de sucesso,** o item é efetivamente removido do ciclo.
        -   **Em caso de falha,** incrementa o contador de `retries` do item.
            -   Se o item ainda não atingiu o `MAX_RETRIES_PER_ITEM`, ele é adicionado a um array `failed`.
            -   Se o limite de tentativas foi atingido, o item é descartado permanentemente e um erro é logado.
    4.  Ao final do loop, se houver itens no array `failed`, eles são adicionados de volta ao início da fila (`queue.unshift(...)`) e uma nova tentativa de reprocessamento é agendada (`scheduleRetry()`).

### `getQueueStats()`

-   **Descrição:** Uma função de monitoramento que retorna o número de itens pendentes na fila e o contador total de falhas desde que a aplicação iniciou. Pode ser usada para expor métricas em um endpoint de `health check`.

## Uso no Sistema

A função `enqueue` é chamada no `rpedService`, dentro do `.catch()` de uma tentativa de escrita no MongoDB.

```javascript
// Exemplo em rpedService.js
persist(document).catch((err) => {
    console.error('Erro na auditoria, enfileirando:', err.message);
    enqueue(persist, document); // Adiciona a tarefa à fila em caso de falha
});
```
