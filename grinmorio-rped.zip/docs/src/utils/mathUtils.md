# `src/utils/mathUtils.js`

Este arquivo é um utilitário que agrupa funções matemáticas puras usadas na lógica do sistema RPED.

## Visão Geral

Ele contém a implementação de baixo nível de algoritmos matemáticos, como a restrição de valores e, mais importante, a lógica de rolagem de dados com pesos.

## Funções Exportadas

### `clamp(value, min, max)`

-   **Descrição:** Uma função auxiliar padrão que restringe (ou "prende") um `value` para que ele não seja menor que `min` nem maior que `max`.
-   **Lógica:** Usa uma combinação de `Math.max` e `Math.min` para garantir que o valor retornado esteja sempre dentro do intervalo `[min, max]`.
-   **Uso no Sistema:** É usada no `rollService` para garantir que o resultado final de uma rolagem, após todas as modificações de Karma e Resgate, nunca seja menor que 1 ou maior que o número de faces do dado.

### `rollWeightedDice(luckLevel, diceSize)`

-   **Descrição:** Esta é a função central que implementa a "rolagem ponderada". Ela simula uma rolagem de dado onde a probabilidade de cada face não é igual, mas sim influenciada pelo `luckLevel` do jogador.
-   **Lógica:**
    1.  **Sanitização de Inputs:** Primeiro, ela usa `clamp` para garantir que `luckLevel` e `diceSize` estejam dentro dos limites definidos em `rpedConstants`.
    2.  **Criação do Array de Pesos:** Cria um array (`weights`) do tamanho do dado, onde cada posição `i` representa a face `i+1`. Inicialmente, todas as faces têm peso `1.0`.
    3.  **Aplicação dos Pesos:** Uma série de `if/else if` modifica os pesos no array com base no `luckLevel`:
        -   **Sorte 0-2 (Azarado):** Aumenta em 2.5x a chance de rolar os 25% valores mais baixos do dado.
        -   **Sorte 3-6 (Neutro/Positivo):** Aumenta em 1.2x a chance de rolar valores na metade superior do dado.
        -   **Sorte 7-8 (Favorecido):** Aumenta em 2.0x a chance de rolar valores na faixa de 55% a 90% do dado.
        -   **Sorte 9-10 ("O Escolhido"):** Aumenta drasticamente (4x e 3x) a chance de rolar os dois valores mais altos e reduz a chance de rolar os dois mais baixos.
    4.  **Amostragem por Inversão (Inversion Sampling):** Este é o algoritmo de sorteio:
        -   Calcula a soma de todos os pesos (`totalWeight`).
        -   Gera um número aleatório entre `0` e `totalWeight`.
        -   Itera pelo array de pesos, subtraindo o peso de cada face do número aleatório. A primeira face cujo peso for maior que o valor restante do número aleatório é a face "sorteada".
-   **Retorno:** Retorna a face sorteada (um número entre 1 e `diceSize`).
-   **Complexidade:** A complexidade do algoritmo é **O(n)**, onde `n` é o `diceSize`, pois ele precisa iterar pelo array de pesos duas vezes. Isso é perfeitamente aceitável para os tamanhos de dados usados (até 1000).

## Pontos de Destaque

-   **Lógica Pura:** As funções neste arquivo são "puras" – elas não têm efeitos colaterais (como chamar o banco de dados) e, para os mesmos inputs, sempre produzirão o mesmo output (exceto pela aleatoriedade intrínseca do `rollWeightedDice`). Isso as torna extremamente fáceis de testar de forma isolada.
-   **Float32Array:** O uso de `new Float32Array` em vez de um array JavaScript padrão é uma micro-otimização que pode oferecer melhor performance e uso de memória para arrays numéricos grandes, embora o impacto seja mínimo para os tamanhos de dados em questão.
-   **Require Interno:** A importação de `rpedConstants` é feita *dentro* da função `rollWeightedDice`. Isso é um padrão incomum, geralmente feito para evitar dependências circulares ou para carregar módulos de forma "lazy". Neste caso, não parece haver um motivo forte, e mover o `require` para o topo do arquivo seria mais convencional.
