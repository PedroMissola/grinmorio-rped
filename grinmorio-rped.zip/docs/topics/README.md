# Documentos de Conceito e Design (`/topics`)

Esta seção da documentação espelha o diretório `/topics` da raiz do projeto.

Enquanto a maior parte desta documentação (`/docs`) foca em explicar o **"COMO"** (como o código está implementado), os arquivos no diretório `/topics` focam em explicar o **"PORQUÊ"** e o **"O QUÊ"**.

Eles são documentos de design de alto nível que descrevem a filosofia do projeto, as mecânicas fundamentais do sistema RPED e a arquitetura planejada, servindo como uma fonte de verdade para a lógica de negócio e os objetivos do sistema.

## Arquivos

-   `Introdução-e-Filosofia.md`: Descreve a motivação por trás do projeto e a filosofia da "intervenção invisível".
-   `Mecânicas-Fundamentais.md`: Detalha os três pilares do sistema de equilíbrio: Sorte, Karma e Resgate.
-   `Algoritmos-de-Equilíbrio-e-Correção.md`: Aprofunda-se nos algoritmos matemáticos e na lógica de "engenharia reversa" dos dados.
-   `Arquitetura-Técnica.md`: Fornece uma visão geral da stack de tecnologia (Node.js, Express, MongoDB, Redis) e da infraestrutura.
-   `Glossário.md`: Define termos específicos usados no projeto.
-   `Experiência-do-Usuário-UX.md`: Discute como as mecânicas devem ser percebidas (ou não percebidas) pelos jogadores.
