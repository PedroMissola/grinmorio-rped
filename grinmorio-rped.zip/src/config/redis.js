const Redis = require('ioredis');
const fs = require('fs');
const path = require('path');

let redisClient;

async function connectRedis() {
    const certsDir = path.join(process.cwd(), 'certs', 'redis');

    const getCertBuffer = (filename) => {
        const filePath = path.join(certsDir, filename);
        if (!fs.existsSync(filePath)) {
            throw new Error(`Certificado Redis não encontrado: ${filePath}`);
        }
        return fs.readFileSync(filePath);
    };

    const tlsConfig = {
        ca: getCertBuffer('ca-certificate.crt'),
        cert: getCertBuffer('certificate.pem'),
        key: getCertBuffer('private-key.key'),
        rejectUnauthorized: true,
        checkServerIdentity: () => undefined
    };

    const redisOptions = {
        tls: tlsConfig,
        maxRetriesPerRequest: 20,
        enableReadyCheck: true,
        connectTimeout: 15000,
        lazyConnect: true,
        retryStrategy(times) {
            if (times > 10) {
                console.error('\x1b[35m[Redis]\x1b[0m Limite de tentativas atingido. Encerrando retries.');
                return null;
            }
            const delay = Math.min(times * 500, 5000);
            console.log(`\x1b[35m[Redis]\x1b[0m Reconexão ${times}/10 em ${delay}ms...`);
            return delay;
        }
    };

    redisClient = new Redis(process.env.REDIS_URI, redisOptions);

    redisClient.on('error', (err) => {
        if (err.code !== 'ECONNRESET') {
            console.error(`\x1b[35m[Redis]\x1b[0m Erro: ${err.message}`);
        }
    });

    redisClient.on('reconnecting', () => {
        console.log('\x1b[35m[Redis]\x1b[0m Reconectando...');
    });

    await redisClient.connect();
    console.log('\x1b[35m[Redis]\x1b[0m \x1b[32mConectado via TLS.\x1b[0m');
}

function getRedisClient() {
    if (!redisClient) throw new Error('Redis não inicializado. Chame connectRedis() primeiro.');
    return redisClient;
}

module.exports = { connectRedis, getRedisClient };